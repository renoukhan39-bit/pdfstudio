from typing import Any

import pkcs11
import pytest
from pyhanko.cli import cli_root
from pyhanko.cli._ctx import CLIContext, PasswordPrompter, UXContext
from pyhanko.cli.commands.signing.pkcs11_cli import (
    P11_PIN_ENV_VAR,
    P11_SIGNING_PIN_ENV_VAR,
)
from pyhanko_testing_commons.test_utils.pkcs11_utils.config import P11TestConfig

from .conftest import (
    INPUT_PATH,
    SIGNED_OUTPUT_PATH,
    DummyPrompter,
    _write_config,
)


@pytest.fixture(
    params=[
        pytest.param(k, marks=pytest.mark.algo(algo=k))
        for k in ('rsa', 'ecdsa', 'ed25519', 'ed448', 'mldsa')
    ]
)
def root_cert_data(p11_config):
    return p11_config.cert_chain[0]


@pytest.fixture
def pinentry_context(p11_config):
    return CLIContext(ux=UXContext(prompter=DummyPrompter(p11_config.user_pin)))


@pytest.mark.hsm(platform='softhsm')
def test_cli_pkcs11_args_required(cli_runner, p11_config):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "--lib and --cert-label are required" in result.output


@pytest.mark.hsm(platform='softhsm')
def test_cli_pkcs11_setup_requires_config(cli_runner, p11_config):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "requires a configuration file" in result.output


@pytest.mark.nosmoke
def test_cli_pkcs11_setup_config_unreadable(cli_runner):
    _write_config({'pkcs11-setups': {}})
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Error while reading PKCS#11 config" in result.output


def _pkcs11_setup_config_pull_certs(p11_test_config: P11TestConfig):
    test_cfg = {
        'module-path': p11_test_config.module,
        'token-criteria': {
            'label': p11_test_config.token_label,
        },
        'cert-label': p11_test_config.cert_label,
        'key-label': p11_test_config.key_label,
        'other-certs-to-pull': p11_test_config.cert_chain_labels[1],
    }
    with open('interm.crt', 'wb') as certf:
        certf.write(p11_test_config.cert_chain[1].dump())
    test_cfg['other-certs'] = 'interm.crt'
    cfg = {'pkcs11-setups': {'test': test_cfg}}
    return cfg


def _pkcs11_setup_config_read_certs_from_file(
    p11_test_config: P11TestConfig,
) -> dict[str, Any]:
    with open('interm.crt', 'wb') as certf:
        certf.write(p11_test_config.cert_chain[1].dump())
    test_cfg = {
        'module-path': p11_test_config.module,
        'token-criteria': {
            'label': p11_test_config.token_label,
        },
        'cert-label': p11_test_config.cert_label,
        'key-label': p11_test_config.key_label,
        'other-certs': 'interm.crt',
    }
    cfg = {'pkcs11-setups': {'test': test_cfg}}
    return cfg


@pytest.mark.hsm(platform='softhsm,yubihsm,nitrokey')
def test_cli_addsig_pkcs11_pull_interm(
    cli_runner,
    post_validate,
    p11_config,
    platform,
    pinentry_context,
):
    args = [
        '--lib',
        p11_config.module,
        '--token-label',
        p11_config.token_label,
        '--cert-label',
        p11_config.cert_label,
        '--other-cert',
        p11_config.cert_chain_labels[1],
    ]
    if p11_config.key_label:
        args += ['--key-label', p11_config.key_label]
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            *args,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
        obj=pinentry_context,
    )
    assert not result.exception, result.output


@pytest.mark.hsm(exclude='safenet')
def test_cli_addsig_pkcs11_read_interm_from_file(
    cli_runner,
    post_validate,
    p11_config,
    platform,
    pinentry_context,
):
    with open('interm.crt', 'wb') as certf:
        certf.write(p11_config.cert_chain[1].dump())
    args = [
        '--lib',
        p11_config.module,
        '--token-label',
        p11_config.token_label,
        '--cert-label',
        p11_config.cert_label,
        '--other-cert-file',
        'interm.crt',
    ]
    if p11_config.key_label:
        args += ['--key-label', p11_config.key_label]
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            *args,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
        obj=pinentry_context,
    )
    assert not result.exception, result.output


@pytest.mark.hsm(exclude='safenet')
@pytest.mark.algo(algo='ecdsa')
@pytest.mark.required_mechanism(pkcs11.Mechanism.ECDSA)
def test_cli_addsig_raw_ecdsa(
    cli_runner,
    post_validate,
    p11_config,
    platform,
    pinentry_context,
):
    with open('interm.crt', 'wb') as certf:
        certf.write(p11_config.cert_chain[1].dump())
    args = [
        '--lib',
        p11_config.module,
        '--token-label',
        p11_config.token_label,
        '--cert-label',
        p11_config.cert_label,
        '--other-cert-file',
        'interm.crt',
    ]
    if p11_config.key_label:
        args += ['--key-label', p11_config.key_label]
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--raw-mechanism',
            *args,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
        obj=pinentry_context,
    )
    assert not result.exception, result.output


@pytest.mark.hsm(exclude='yubikey-nano')
def test_cli_addsig_pkcs11_with_setup_pull_certs(
    cli_runner, p11_config, post_validate, platform
):
    cfg = _pkcs11_setup_config_pull_certs(p11_config)
    cfg['pkcs11-setups']['test']['user-pin'] = p11_config.user_pin
    if p11_config.signing_pin is not None:
        cfg['pkcs11-setups']['test']['signing-pin-mode'] = 'reauthenticate'
        cfg['pkcs11-setups']['test']['signing-pin'] = p11_config.signing_pin
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.hsm
def test_cli_addsig_pkcs11_with_setup_read_certs_from_file(
    cli_runner, p11_config, post_validate, platform
):
    cfg = _pkcs11_setup_config_read_certs_from_file(p11_config)
    cfg['pkcs11-setups']['test']['user-pin'] = p11_config.user_pin
    if p11_config.signing_pin is not None:
        cfg['pkcs11-setups']['test']['signing-pin-mode'] = 'reauthenticate'
        cfg['pkcs11-setups']['test']['signing-pin'] = p11_config.signing_pin
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.hsm
@pytest.mark.algo(algo='ecdsa')
@pytest.mark.required_mechanism(pkcs11.Mechanism.ECDSA)
def test_cli_addsig_pkcs11_with_setup_raw_ecdsa(
    cli_runner, p11_config, post_validate, platform
):
    cfg = _pkcs11_setup_config_read_certs_from_file(p11_config)
    cfg['pkcs11-setups']['test']['raw-mechanism'] = True
    cfg['pkcs11-setups']['test']['user-pin'] = p11_config.user_pin
    if p11_config.signing_pin is not None:
        cfg['pkcs11-setups']['test']['signing-pin-mode'] = 'reauthenticate'
        cfg['pkcs11-setups']['test']['signing-pin'] = p11_config.signing_pin
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.hsm(platform='safenet')
def test_cli_addsig_pkcs11_with_setup_and_signing_pin_prompt(
    cli_runner,
    p11_config,
    post_validate,
    platform,
):
    cfg = _pkcs11_setup_config_pull_certs(p11_config)

    class SpecialDummyPrompter(PasswordPrompter):
        def prompt_for_password(self, prompt: str) -> str:
            if 'signing' in prompt:
                return p11_config.signing_pin
            else:
                return p11_config.user_pin

    if p11_config.signing_pin is not None:
        cfg['pkcs11-setups']['test']['signing-pin-mode'] = 'prompt'
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
        obj=CLIContext(ux=UXContext(prompter=SpecialDummyPrompter())),
    )
    assert not result.exception, result.output


@pytest.mark.hsm(platform='softhsm')
@pytest.mark.algo(algo='ed25519')
def test_cli_addsig_pkcs11_with_setup_and_env_pin(
    cli_runner, p11_config, post_validate
):
    cli_runner.env[P11_PIN_ENV_VAR] = p11_config.user_pin
    cfg = _pkcs11_setup_config_pull_certs(p11_config)
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.hsm(platform='safenet')
def test_cli_addsig_pkcs11_with_setup_and_env_signing_pin(
    cli_runner, p11_config, post_validate
):
    cli_runner.env[P11_PIN_ENV_VAR] = p11_config.user_pin
    cli_runner.env[P11_SIGNING_PIN_ENV_VAR] = p11_config.signing_pin
    cfg = _pkcs11_setup_config_pull_certs(p11_config)
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.hsm(platform='softhsm')
@pytest.mark.algo(algo='ed25519')
def test_cli_addsig_pkcs11_with_setup_and_pin_prompt(
    cli_runner,
    post_validate,
    p11_config,
    pinentry_context,
):
    cfg = _pkcs11_setup_config_pull_certs(p11_config)
    _write_config(cfg)

    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs11',
            '--p11-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
        obj=pinentry_context,
    )
    assert not result.exception, result.output
