import asyncio
from asyncio import to_thread
from collections.abc import Awaitable
from typing import Any

import requests

from ..api import DEFAULT_USER_AGENT
from ..common_utils import FetchBudget, FetchKind, queue_fetch_task

__all__ = ['RequestsFetcherMixin']


class RequestsFetcherMixin:
    def __init__(
        self,
        user_agent=None,
        per_request_timeout=10,
        *,
        budget: FetchBudget | None = None,
    ):
        self._budget = budget
        self.user_agent = user_agent or DEFAULT_USER_AGENT
        self.per_request_timeout = per_request_timeout
        self.__results: dict[Any, Any] = {}
        self.__result_events: dict[Any, asyncio.Event] = {}

    def _charge(self, kind: FetchKind):
        # runs on the event loop thread, before dispatching to a worker thread
        if self._budget is not None:
            self._budget.charge(kind)

    def get_results(self):
        return {
            v for v in self.__results.values() if not isinstance(v, Exception)
        }

    def _iter_results(self):
        for k, v in self.__results.items():
            if not isinstance(v, Exception):
                yield k, v

    def _cached_success(self, tag):
        result = self.__results.get(tag)
        return None if isinstance(result, Exception) else result

    async def _perform_fetch(self, tag, fetch_fun):
        return await queue_fetch_task(
            self.__results, self.__result_events, tag, fetch_fun
        )

    def _get(
        self, url, *, acceptable_content_types
    ) -> Awaitable[requests.Response]:
        def task():
            headers = {
                'Accept': ','.join(acceptable_content_types),
                'User-Agent': self.user_agent,
            }
            response = requests.get(
                url=url, timeout=self.per_request_timeout, headers=headers
            )
            if response.status_code != 200:
                raise requests.RequestException(
                    f"status code {response.status_code}"
                )
            return response

        return to_thread(task)

    def _post(
        self, url, data, *, content_type, acceptable_content_types
    ) -> Awaitable[requests.Response]:
        def task():
            headers = {
                'Accept': ','.join(acceptable_content_types),
                'User-Agent': self.user_agent,
                'Content-Type': content_type,
            }
            response = requests.post(
                url=url,
                timeout=self.per_request_timeout,
                headers=headers,
                data=data,
            )
            if response.status_code != 200:
                raise requests.RequestException(
                    f"status code {response.status_code}"
                )
            return response

        return to_thread(task)
