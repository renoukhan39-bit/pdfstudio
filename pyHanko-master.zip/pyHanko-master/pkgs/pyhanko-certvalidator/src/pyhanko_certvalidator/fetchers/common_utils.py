"""
Internal backend-agnostic utilities to help process fetched certificates, CRLs
and OCSP responses.
"""

import asyncio
import enum
import logging
import os
from asyncio import Future
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

from asn1crypto import algos, cms, core, ocsp, pem, x509
from asn1crypto.x509 import DistributionPoint

from .. import errors
from ..authority import Authority
from ..util import get_ac_extension_value
from .api import FetchLimits

__all__ = [
    'ACCEPTABLE_CERT_DER_ALIASES',
    'ACCEPTABLE_CERT_PEM_ALIASES',
    'ACCEPTABLE_PKCS7_DER_ALIASES',
    'ACCEPTABLE_STRICT_CERT_CONTENT_TYPES',
    'complete_certificate_fetch_jobs',
    'crl_fetch_url_groups',
    'crl_job_results_as_completed',
    'enumerate_delivery_point_urls',
    'first_successful_fetch',
    'format_ocsp_request',
    'gather_aia_issuer_urls',
    'ocsp_job_get_earliest',
    'process_ocsp_response_data',
    'queue_fetch_task',
    'unpack_cert_content',
]

logger = logging.getLogger(__name__)

ACCEPTABLE_STRICT_CERT_CONTENT_TYPES = frozenset(
    [
        'application/pkix-cert',
        'application/pkix-ca',
        'application/pkcs7-mime',
        'application/x-x509-ca-cert',
        'application/x-pkcs7-certificates',
    ]
)

ACCEPTABLE_CERT_PEM_ALIASES = frozenset(
    [
        'application/x-pem-file',
        'text/plain',
        'application/octet-stream',
        'binary/octet-stream',
    ]
)

ACCEPTABLE_CERT_DER_ALIASES = frozenset(
    [
        'application/pkix-cert',
        'application/x-x509-ca-cert',
        'application/octet-stream',
        'binary/octet-stream',
    ]
)

ACCEPTABLE_PKCS7_DER_ALIASES = frozenset(
    [
        'application/pkcs7-mime',
        'application/x-pkcs7-certificates',
        'application/octet-stream',
        'binary/octet-stream',
    ]
)


class FetchKind(enum.Enum):
    CERT = errors.CertificateFetchError
    CRL = errors.CRLFetchError
    OCSP = errors.OCSPFetchError


class FetchBudget:
    """
    Request counters enforcing a :class:`.FetchLimits` object.

    Not thread-safe: :meth:`charge` must be called on the event loop thread,
    before any work is dispatched to a worker thread.
    """

    def __init__(self, limits: FetchLimits):
        self.limits = limits
        self._requests = 0
        self._cert_requests = 0
        self._exhausted_logged = False

    def charge(self, kind: FetchKind):
        """
        Account for one network request that is about to be made.

        :raises:
            The fetch error type matching ``kind`` if a limit was reached.
        """
        limits = self.limits
        if limits.max_requests is not None and (
            self._requests >= limits.max_requests
        ):
            self._refuse(kind, f"{limits.max_requests} requests")
        if kind is FetchKind.CERT:
            if limits.max_cert_requests is not None and (
                self._cert_requests >= limits.max_cert_requests
            ):
                self._refuse(
                    kind, f"{limits.max_cert_requests} certificate requests"
                )
            self._cert_requests += 1
        self._requests += 1

    def _refuse(self, kind: FetchKind, limit_description: str):
        msg = f"Fetch limit of {limit_description} reached."
        if self._exhausted_logged:
            logger.debug(msg)
        else:
            self._exhausted_logged = True
            logger.warning(f"{msg} Further fetches will be refused.")
        raise kind.value(msg)


def cap_aia_urls(budget: FetchBudget | None, urls: Iterable[str]) -> list[str]:
    url_list = list(urls)
    limit = budget.limits.max_aia_urls_per_object if budget else None
    if limit is not None and len(url_list) > limit:
        logger.warning(
            f"Found {len(url_list)} caIssuers URLs, but only {limit} are "
            f"allowed per certificate or CRL. Ignoring the rest."
        )
        return url_list[:limit]
    return url_list


def unpack_cert_content(
    response_data: bytes,
    content_type: str | None,
    url: str,
    permit_pem: bool,
):
    is_pem = pem.detect(response_data)
    if (
        content_type is None or content_type in ACCEPTABLE_CERT_DER_ALIASES
    ) and not is_pem:
        # sometimes we get DER over octet-stream
        if content_type is None:
            logger.warning(
                f"Response to certificate fetch request to {url} did not "
                f"include a content type, verifying it's sequence length to "
                f"check if it is a certificate or pkcs7."
            )
        der_sequence_length = len(core.Sequence.load(response_data))
        if der_sequence_length == 2:
            yield from _unpack_der_pkcs7(response_data, url)
        elif der_sequence_length == 3:
            yield x509.Certificate.load(response_data)
        else:
            raise ValueError(
                f"Failed to heuristically determine content of payload from source URL {url}"
            )
    elif (content_type in ACCEPTABLE_PKCS7_DER_ALIASES) and not is_pem:
        yield from _unpack_der_pkcs7(response_data, url)
    elif permit_pem and is_pem:
        # technically, PEM is not allowed here, but of course some people don't
        # bother following the rules
        for type_name, _, data in pem.unarmor(response_data, multiple=True):
            if type_name == 'PKCS7':
                yield from _unpack_der_pkcs7(data, url)
            else:
                yield x509.Certificate.load(data)
    else:
        raise ValueError(
            f"Failed to extract certs from {content_type} payload. "
            f"Source URL: {url}."
        )


def _unpack_der_pkcs7(pkcs7_data: bytes, pkcs7_url: str):
    content_info: cms.ContentInfo = cms.ContentInfo.load(pkcs7_data)
    cms_ct = content_info['content_type'].native
    if cms_ct != 'signed_data':
        raise ValueError(
            "Expected CMS SignedData when extracting certs from "
            "application/pkcs7-mime payload, but content type was "
            f"'{cms_ct}'. Source URL: {pkcs7_url}."
        )
    signed_data = content_info['content']
    if isinstance(signed_data['certificates'], cms.CertificateSet):
        for cert_choice in signed_data['certificates']:
            if cert_choice.name == 'certificate':
                yield cert_choice.chosen


def get_certid(
    cert: x509.Certificate | cms.AttributeCertificateV2,
    authority: Authority,
    *,
    certid_hash_algo,
) -> ocsp.CertId:
    if isinstance(cert, x509.Certificate):
        serial_number = cert.serial_number
    else:
        serial_number = cert['ac_info']['serial_number'].native

    iss_name_hash = getattr(authority.name, certid_hash_algo)
    cert_id = ocsp.CertId(
        {
            'hash_algorithm': algos.DigestAlgorithm(
                {'algorithm': certid_hash_algo}
            ),
            'issuer_name_hash': iss_name_hash,
            'issuer_key_hash': getattr(authority.public_key, certid_hash_algo),
            'serial_number': serial_number,
        }
    )
    return cert_id


def format_ocsp_request(
    cert: x509.Certificate,
    authority: Authority,
    *,
    certid_hash_algo: str,
    request_nonces: bool,
):
    cert_id = get_certid(cert, authority, certid_hash_algo=certid_hash_algo)

    request = ocsp.Request(
        {
            'req_cert': cert_id,
        }
    )
    tbs_request = ocsp.TBSRequest(
        {
            'request_list': ocsp.Requests([request]),
        }
    )

    if request_nonces:
        nonce_extension = ocsp.TBSRequestExtension(
            {
                'extn_id': 'nonce',
                'critical': False,
                'extn_value': core.OctetString(os.urandom(16)),
            }
        )
        tbs_request['request_extensions'] = ocsp.TBSRequestExtensions(
            [nonce_extension]
        )

    return ocsp.OCSPRequest({'tbs_request': tbs_request})


def process_ocsp_response_data(
    response_data: bytes, *, ocsp_request: ocsp.OCSPRequest, ocsp_url: str
):
    try:
        ocsp_response = ocsp.OCSPResponse.load(response_data)
    except ValueError:
        raise errors.OCSPFetchError('Failed to parse response from OCSP server')
    status = ocsp_response['response_status'].native
    if status != 'successful':
        raise errors.OCSPValidationError(
            f'OCSP server at {ocsp_url} returned an error. Status was \'{status}\'.'
        )

    request_nonce = ocsp_request.nonce_value
    if request_nonce:
        response_nonce = ocsp_response.nonce_value
        # if the response did not contain the nonce extension, there's no
        # point in trying to enforce it, that's the CA's problem.
        #  (I suppose we could give callers the option to mark the nonce
        #  extension as critical in the request, but that's discouraged by the
        #  specification)
        if response_nonce and (request_nonce.native != response_nonce.native):
            raise errors.OCSPValidationError(
                'Unable to verify OCSP response since the request and '
                'response nonces do not match'
            )
    return ocsp_response


T = TypeVar('T')
R = TypeVar('R')


async def queue_fetch_task(
    results: dict[T, R | Exception],
    running_jobs: dict[T, asyncio.Event],
    tag: T,
    async_fun: Callable[[], Awaitable[R]],
) -> R | Exception:
    # use an asyncio events to make sure that we don't attempt to re-fetch
    # the same tag while the job is running
    # Note: this uses asyncio locking, so we only transfer control
    # on 'await'.
    # We use events instead of locks because we don't care about fairness,
    # and events are easier to reason about.
    while True:
        try:
            result = results[tag]
            logger.debug(
                f"Result for fetch job with tag {tag!r} was available in cache."
            )
            return _return_or_raise(result)
        except KeyError:
            pass
        wait_event = running_jobs.get(tag)
        if wait_event is None:
            break
        logger.debug(f"Waiting for fetch job with tag {tag!r} to return...")
        await wait_event.wait()
        # If the job we waited for was cancelled (e.g. because it lost a race
        # in another caller), it won't have stored a result, so we go around
        # again and take over.
        logger.debug(
            f"Received completion signal or "
            f"cancellation for job with tag {tag!r}."
        )

    logger.debug(f"Starting new fetch job with tag {tag!r}...")
    running_jobs[tag] = wait_event = asyncio.Event()
    try:
        try:
            result = await async_fun()
        except Exception as e:  # noqa: BLE001
            logger.debug(
                f"New fetch job with tag {tag!r} threw an exception: {e}"
            )
            result = e
        results[tag] = result
        logger.debug(f"New fetch job with tag {tag!r} returned.")
    finally:
        # Waiters must always be released, also when we're cancelled, or they
        # would hang forever.
        del running_jobs[tag]
        wait_event.set()
    return _return_or_raise(result)


def _return_or_raise(result):
    if isinstance(result, Exception):
        raise result
    return result


async def crl_job_results_as_completed(jobs):
    last_e = None
    at_least_one_success = False
    for crl_job in asyncio.as_completed(list(jobs)):
        try:
            fetched_crl = await crl_job
            at_least_one_success = True
            yield fetched_crl
        except errors.CRLFetchError as e:
            last_e = e

    if last_e is not None and not at_least_one_success:
        raise last_e


async def cancel_all(pending_tasks):
    pending = asyncio.gather(*pending_tasks)
    pending.cancel()
    try:
        await pending
    except asyncio.CancelledError:
        pass


async def first_successful_fetch(
    jobs: Iterable[Awaitable[R]], kind: FetchKind
) -> R:
    """
    Run fetch jobs concurrently, and return the result of the first one
    to complete successfully. The remaining jobs are then cancelled.

    :param jobs:
        The jobs to run. These must be interchangeable.
    :param kind:
        The kind of fetch being performed.
    :return:
        The first successful result.
    :raises:
        The fetch error type matching ``kind`` if all jobs failed (or if
        there were no jobs at all).
    """
    error_type = kind.value
    queue: Iterable[Future[R]] = [asyncio.ensure_future(job) for job in jobs]
    last_e = None
    try:
        while queue:
            done, queue = await asyncio.wait(
                queue, return_when=asyncio.FIRST_COMPLETED
            )
            successes = []
            # consume all completed jobs, so that no exception goes unretrieved
            for job in done:
                try:
                    successes.append(job.result())
                except error_type as e:
                    last_e = e
            if successes:
                return successes[0]
    finally:
        await cancel_all(queue)
    raise last_e or error_type(f"No {kind.name} results")


async def ocsp_job_get_earliest(jobs):
    return await first_successful_fetch(jobs, FetchKind.OCSP)


def gather_aia_issuer_urls(
    cert: x509.Certificate | cms.AttributeCertificateV2,
):
    if isinstance(cert, x509.Certificate):
        aia_value = cert.authority_information_access_value
    else:
        aia_value = get_ac_extension_value(cert, 'authority_information_access')
    if aia_value is None:
        return
    for entry in aia_value:
        if entry['access_method'].native == 'ca_issuers':
            location = entry['access_location']
            if location.name != 'uniform_resource_identifier':
                continue
            url = location.native
            if url.startswith('http'):
                yield url


async def complete_certificate_fetch_jobs(fetch_jobs):
    for fetch_job in asyncio.as_completed(fetch_jobs):
        try:
            certs_fetched = await fetch_job
        except errors.CertificateFetchError as e:
            logger.warning(
                f'Error during certificate fetch job, skipping... (Error: {e})',
            )
            continue
        for cert in certs_fetched:
            yield cert


def enumerate_delivery_point_urls(distribution_point: DistributionPoint):
    name = distribution_point['distribution_point']
    if isinstance(name, core.Void):
        return
    if name.name != 'full_name':
        logger.debug(
            f"Relative delivery point name {name.chosen.native!r} is not supported"
        )
        # We don't support relative DPs
        #  (esp. since we don't support directory-based lookups at all)
        return

    for general_name in name.chosen:
        if general_name.name == 'uniform_resource_identifier':
            url = general_name.native
            # Only fetch CRLs over http
            #  (or https, but that doesn't really happen all that often)
            # In particular, don't attempt to grab CRLs over LDAP
            if url.lower().startswith(('http://', 'https://')):
                yield url


def _has_global_scope(distribution_point: DistributionPoint) -> bool:
    # RFC 5280 requires the CRL behind a DP that omits both the reasons and
    # the cRLIssuer field to be issued by the certificate's issuer, and to
    # cover all revocation reasons. So all such DPs are interchangeable.
    return isinstance(distribution_point['reasons'], core.Void) and isinstance(
        distribution_point['crl_issuer'], core.Void
    )


def _group_distribution_point_urls(
    distribution_points: x509.CRLDistributionPoints | None,
) -> list[list[str]]:
    global_urls: list[str] = []
    groups = []
    for distribution_point in distribution_points or ():
        urls = list(enumerate_delivery_point_urls(distribution_point))
        if not urls:
            continue
        if _has_global_scope(distribution_point):
            global_urls.extend(url for url in urls if url not in global_urls)
        else:
            groups.append(urls)
    if global_urls:
        groups.insert(0, global_urls)
    return groups


def crl_fetch_url_groups(
    cert: x509.Certificate | cms.AttributeCertificateV2, *, use_deltas: bool
) -> list[list[str]]:
    """
    Group the HTTP(S) URLs from which CRLs for a certificate can be fetched
    into sets of alternatives.

    URLs listed under the same distribution point are always alternatives.
    URLs from different distribution points are only considered alternatives
    if neither distribution point is limited to a subset of revocation
    reasons or delegates to a different CRL issuer.
    Complete CRLs and delta CRLs are never mixed in the same group.

    :param cert:
        The certificate (or attribute certificate) of interest.
    :param use_deltas:
        Whether to include delta CRL distribution points.
    :return:
        A list of groups of URLs. Fetching one CRL from each group should
        be sufficient.
    """
    if isinstance(cert, x509.Certificate):
        complete_dps = cert.crl_distribution_points_value
        delta_dps = cert.freshest_crl_value
    else:
        complete_dps = get_ac_extension_value(cert, 'crl_distribution_points')
        delta_dps = get_ac_extension_value(cert, 'freshest_crl')
    groups = _group_distribution_point_urls(complete_dps)
    if use_deltas:
        groups.extend(_group_distribution_point_urls(delta_dps))
    return groups
