package api

import (
	"context"
	"errors"
	"log/slog"

	"github.com/gotenberg/gotenberg/v9/pkg/gotenberg"
)

// ApiMock is a mock for the [Converter] interface.
type ApiMock struct {
	PdfMock        func(ctx context.Context, logger *slog.Logger, inputPath, outputPath string, options Options) error
	ExtensionsMock func() []string
}

// Pdf calls PdfMock.
func (api *ApiMock) Pdf(ctx context.Context, logger *slog.Logger, inputPath, outputPath string, options Options) error {
	return api.PdfMock(ctx, logger, inputPath, outputPath, options)
}

// Extensions calls ExtensionsMock.
func (api *ApiMock) Extensions() []string {
	return api.ExtensionsMock()
}

// ProviderMock is a mock for the [Provider] interface.
type ProviderMock struct {
	LibreOfficeMock func() (Converter, error)
}

// LibreOffice calls LibreOfficeMock.
func (provider *ProviderMock) LibreOffice() (Converter, error) {
	return provider.LibreOfficeMock()
}

// libreOfficeMock is a mock for the [libreOffice] interface.
type libreOfficeMock struct {
	errCrashedCount int

	gotenberg.ProcessMock
	pdfMock func(ctx context.Context, logger *slog.Logger, inputPath, outputPath string, options Options) error
}

func (b *libreOfficeMock) pdf(ctx context.Context, logger *slog.Logger, inputPath, outputPath string, options Options) error {
	err := b.pdfMock(ctx, logger, inputPath, outputPath, options)
	if errors.Is(err, ErrCrashed) {
		b.errCrashedCount += 1
	}
	if b.errCrashedCount > 1 {
		return nil
	}
	return err
}

// Interface guards.
var (
	_ Converter   = (*ApiMock)(nil)
	_ Provider    = (*ProviderMock)(nil)
	_ libreOffice = (*libreOfficeMock)(nil)
)
