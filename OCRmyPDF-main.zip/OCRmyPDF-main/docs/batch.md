% SPDX-FileCopyrightText: 2022 James R. Barlow
% SPDX-License-Identifier: CC-BY-SA-4.0

Batch processing
================

This article provides information about running OCRmyPDF on multiple
files or configuring it as a service triggered by file system events.

Batch jobs
----------

Consider using the excellent [GNU
Parallel](https://www.gnu.org/software/parallel/) to apply OCRmyPDF to
multiple files at once.

Both `parallel` and `ocrmypdf` will try to use all available processors.
To maximize parallelism without overloading your system with processes,
consider using `parallel -j 2` to limit parallel to running two jobs at
once.

This command will run `ocrmypdf` on all files named `*.pdf` in the
current directory and write them to the previously created `output/`
folder. It will not search subdirectories.

The `--tag` argument tells parallel to print the filename as a prefix
whenever a message is printed, so that one can trace any errors to the
file that produced them.

:::{code} bash
parallel --tag -j 2 ocrmypdf '{}' 'output/{}' ::: *.pdf
:::

OCRmyPDF automatically repairs PDFs before parsing and gathering
information from them.

Directory trees
---------------

This will walk through a directory tree and run OCR on all files in
place, and printing each filename in between runs:

:::{code} bash
find . -name '*.pdf' -printf '%p\n' -exec ocrmypdf '{}' '{}' \;
:::

This only runs one `ocrmypdf` process at a time. This variation uses
`find` to create a directory list and `parallel` to parallelize runs of
`ocrmypdf`, again updating files in place.

:::{code} bash
find . -name '*.pdf' | parallel --tag -j 2 ocrmypdf '{}' '{}'
:::

In a Windows batch file, use

:::{code} bat
for /r %%f in (*.pdf) do ocrmypdf %%f %%f
:::

With a Docker container, you will need to stream through standard input
and output:

:::{code} bash
find . -name '*.pdf' -print0 | xargs -0 | while read pdf; do
    pdfout=$(mktemp)
    docker run --rm -i jbarlow83/ocrmypdf - - <$pdf >$pdfout && cp $pdfout $pdf
done
:::

### Sample script

This user contributed script also provides an example of batch
processing.

:::{literalinclude} ../misc/batch.py
---
caption: misc/batch.py
---
:::

### Synology DiskStations

Synology DiskStations (Network Attached Storage devices) can run the
Docker image of OCRmyPDF if the Synology [Docker
package](https://www.synology.com/en-global/dsm/packages/Docker) is
installed. Attached is a script to address particular quirks of using
OCRmyPDF on one of these devices.

At the time this script was written, it only worked for x86-based
Synology products. It is not known if it will work on ARM-based Synology
products. Further adjustments might be needed to deal with the
Synology\'s relatively limited CPU and RAM.

:::{literalinclude} ../misc/synology.py
---
caption: misc/synology.py - Sample script for Synology DiskStations
---
:::

### Huge batch jobs

If you have thousands of files to work with, contact the author.
Consulting work related to OCRmyPDF helps fund this open source project
and all inquiries are appreciated.

Hot (watched) folders
---------------------

### Watched folders with watcher.py

OCRmyPDF has a folder watcher called watcher.py, which is currently
included in source distributions but not part of the main program. It
may be used natively or may run in a Docker container. Native instances
tend to give better performance. watcher.py works on all platforms.

Users may need to customize the script to meet their requirements.

:::{code} bash
# Using uv (recommended)
uv sync --extra watcher

# Or using pip
pip3 install ocrmypdf[watcher]

env OCR_INPUT_DIRECTORY=/mnt/input-pdfs \
    OCR_OUTPUT_DIRECTORY=/mnt/output-pdfs \
    OCR_OUTPUT_STRUCTURE=YEAR_MONTH \
    python3 watcher.py
:::

:::{list-table} watcher.py environment variables
---
header-rows: 1
---

* - Environment variable
  - Description
* - OCR\_INPUT\_DIRECTORY
  - Set input directory to monitor (recursive)
* - OCR\_OUTPUT\_DIRECTORY
  - Set output directory (should not be under input)
* - OCR\_ARCHIVE\_DIRECTORY
  - Set archive directory for processed originals (should not be under input, requires `OCR_ON_SUCCESS_ARCHIVE` to be set)
* - OCR\_ON\_SUCCESS\_DELETE
  - Delete the input file if the exit code is 0 (OK). Takes precedence over `OCR_ON_SUCCESS_ARCHIVE` if both are set.
* - OCR\_ON\_SUCCESS\_ARCHIVE
  - Move the processed original file to `OCR_ARCHIVE_DIRECTORY` if the exit code is 0 (OK). Note that `OCR_ON_SUCCESS_DELETE` takes precedence over this option, i.e. if both options are set, the input file will be deleted.
* - OCR\_OUTPUT\_STRUCTURE (`--output-structure`)
  - How output (and archived) files are laid out under their destination
    directory. One of `FLAT` (default; all files directly in the
    destination directory), `YEAR_MONTH` (`{destination}/{year}/{month}/{filename}`),
    or `HIERARCHY` (mirrors the input directory tree, e.g.
    `input/a/b/c.pdf` → `{destination}/a/b/c.pdf`). Applies to both
    `OCR_OUTPUT_DIRECTORY` and `OCR_ARCHIVE_DIRECTORY`.
* - OCR\_ON\_CONFLICT (`--on-conflict`)
  - What to do when the intended destination file already exists. One of
    `SUFFIX` (default; write `name (1).pdf`, `name (2).pdf`, ... in the OS
    style), `SKIP` (log and leave the file unprocessed), or `OVERWRITE`
    (replace the existing file, the previous default behavior). Applies to
    both `OCR_OUTPUT_DIRECTORY` and `OCR_ARCHIVE_DIRECTORY`.
* - OCR\_OUTPUT\_DIRECTORY\_YEAR\_MONTH
  - **Deprecated** in favor of `OCR_OUTPUT_STRUCTURE=YEAR_MONTH`. Still
    honored, and logs a deprecation warning; if both variables are set,
    `OCR_OUTPUT_STRUCTURE` takes precedence.
* - OCR\_DESKEW
  - Apply deskew to crooked input PDFs
* - OCR\_JSON\_SETTINGS
  - A JSON string specifying any other arguments for `ocrmypdf.ocr`, e.g. `'OCR_JSON_SETTINGS={"rotate_pages": true, "optimize": "3"}'`.
* - OCR\_POLL\_NEW\_FILE\_SECONDS
  - Polling interval
* - OCR\_LOGLEVEL
  - Level of log messages (DEBUG, INFO, WARNING, ERROR, CRITICAL)
:::

One could configure a networked scanner or scanning computer to drop
files in the watched folder.

Output and archive filenames, and any directory components generated by
`OCR_OUTPUT_STRUCTURE`, are sanitized for compatibility with the output
filesystem: characters that are illegal on Windows or SMB shares
(`<>:"/\|?*` and control characters) are replaced with `_`, trailing dots
and spaces are stripped, and reserved DOS device names (`CON`, `PRN`,
`AUX`, `NUL`, `COM1`-`COM9`, `LPT1`-`LPT9`) are prefixed with `_`. This is
done unconditionally because the output directory may sit on a more
restrictive filesystem (e.g. an SMB share) than the input side, even when
the watcher itself runs on Linux or macOS.

:::{note}
If you write output to an SMB share and mount it on a Windows client, newly
written files may not appear immediately in Windows Explorer or `dir`. This
is the SMB client's own directory and file-info cache
(`DirectoryCacheLifetime` / `FileInfoCacheLifetime`, ~10 seconds by
default), not a delay introduced by the watcher. It can be tuned on the
client, e.g. with `Set-SmbClientConfiguration`; the watcher deliberately
does not attempt server-side workarounds for a client-side cache.
:::

### Watcher security model

`watcher.py` treats the input, output and archive directories as *data
only* — they may be writable by less-privileged users, but code must never
live in or be executed from them (a "Harvard architecture"). To enforce this,
the watcher validates its configuration at startup and refuses to run
(exiting with code 9, *invalid configuration*) if any of these conditions is
violated:

* Any of the input, output or archive directories overlaps a Python
  interpreter path — `sys.executable`, `sys.path`, the virtual environment,
  the site-packages directories, or any directory on `$PATH`. This prevents
  an attacker who can write to a data directory from modifying the interpreter
  or the code that runs.
* `OCR_JSON_SETTINGS` names a file that lives inside a data directory, or that
  is group- or world-writable. Keep the settings file outside the data
  directories and restrict it to owner-only write access (e.g. `chmod 600`).
* `OCR_JSON_SETTINGS` specifies a plugin (a `.py` path) located inside a data
  directory.

* The output or archive directory is the input directory or a subdirectory of
  it. Because the input directory is watched recursively, OCRmyPDF output (and
  archived originals) written there would be detected as new input and
  reprocessed endlessly. Keep the output and archive directories outside the
  input directory.

At runtime the watcher also refuses to follow symlinks or process non-regular
files (such as fifos or devices) in the input directory, and refuses to write
output onto a destination occupied by a non-regular file.

### Watched folders with Docker

The watcher service is included in the OCRmyPDF Docker image. To run it:

:::{code} bash
docker run \
    --volume <path to files to convert>:/input \
    --volume <path to store results>:/output \
    --volume <path to store processed originals>:/processed \
    --env OCR_OUTPUT_STRUCTURE=YEAR_MONTH \
    --env OCR_ON_SUCCESS_ARCHIVE=1 \
    --env OCR_DESKEW=1 \
    --env PYTHONUNBUFFERED=1 \
    --interactive --tty --entrypoint python3 \
    jbarlow83/ocrmypdf \
    /app/watcher.py
:::

:::{note}
The image runs as the non-root `app` user (uid 1000) by default, so it
may not be able to write to the `/output` and `/processed` volumes unless
you add a `--user` argument. The correct value depends on whether you use
rootful Docker, rootless Docker, or Podman -- see
{ref}`Bind-mounted volumes <docker-volumes>` for details.
:::

This service will watch for a file that matches `/input/\*.pdf`, convert
it to a OCRed PDF in `/output/`, and move the processed original to
`/processed`. The parameters to this image are:

:::{list-table} Watcher Docker Parameters
:header-rows: 1

* - Parameter
  - Description
* - `--volume <path to files to convert>:/input`
  - Files placed in this location will be OCRed
* - `--volume <path to store results>:/output`
  - This is where OCRed files will be stored
* - `--volume <path to store processed originals>:/processed`
  - Archive processed originals here
* - `--env OCR_OUTPUT_STRUCTURE=YEAR_MONTH`
  - Define environment variable `OCR_OUTPUT_STRUCTURE` to lay out output
    (and archived) files as `FLAT` (default), `YEAR_MONTH`
    (`{destination}/{year}/{month}/{filename}`), or `HIERARCHY` (mirrors
    the input directory tree). Replaces the deprecated
    `OCR_OUTPUT_DIRECTORY_YEAR_MONTH=1`.
* - `--env OCR_ON_CONFLICT=SUFFIX`
  - Define environment variable `OCR_ON_CONFLICT` to control what happens
    when a destination file already exists: `SUFFIX` (default, appends
    " (1)", " (2)", ...), `SKIP`, or `OVERWRITE`
* - `--env OCR_ON_SUCCESS_ARCHIVE=1`
  - Define environment variable `OCR_ON_SUCCESS_ARCHIVE` to move processed originals
* - `--env OCR_DESKEW=1`
  - Define environment variable `OCR_DESKEW` to apply deskew to crooked input PDFs
* - `--env PYTHONBUFFERED=1`
  - This will force `STDOUT` to be unbuffered and allow you to see messages in docker logs
* - `--env OCR_LOGLEVEL='DEBUG'`
  - Level of log messages
* - `--env OCR_JSON_SETTINGS={"language":"deu+eng", "rotate_pages": true}`
  - A JSON string specifying any other arguments for `ocrmypdf.ocr`
:::

This service uses native operating system filesystem notifications to detect
changes. On some environments, such as filesystems shared on a slow network,
these notifications may be unreliable; set `OCR_USE_POLLING=1` to fall back to
polling in that case.

A configuration manager such as Docker Compose could be used to ensure
that the service is always available.

:::{literalinclude} ../misc/docker-compose.example.yml
---
caption: misc/docker-compose.example.yml
---
:::

### Caveats

-   `watchmedo` may not work properly on a networked file system,
    depending on the capabilities of the file system client and server.
-   This simple recipe does not filter for the type of file system
    event, so file copies, deletes and moves, and directory operations,
    will all be sent to ocrmypdf, producing errors in several cases.
    Disable your watched folder if you are doing anything other than
    copying files to it.
-   If the source and destination directory are the same, watchmedo may
    create an infinite loop.
-   On BSD, FreeBSD and older versions of macOS, you may need to
    increase the number of file descriptors to monitor more files, using
    `ulimit -n 1024` to watch a folder of up to 1024 files.

### Alternatives

-   On Linux, [systemd user
    services](https://wiki.archlinux.org/index.php/Systemd/User) can be
    configured to automatically perform OCR on a collection of files.
-   [Watchman](https://facebook.github.io/watchman/) is a more powerful
    alternative to `watchmedo`.

macOS Automator
---------------

You can use the Automator app with macOS, to create a Workflow or Quick
Action. Use a *Run Shell Script* action in your workflow. In the context
of Automator, the `PATH` may be set differently your Terminal\'s `PATH`;
you may need to explicitly set the PATH to include `ocrmypdf`. The
following example may serve as a starting point:

![](images/macos-workflow.png)

You may customize the command sent to ocrmypdf.
