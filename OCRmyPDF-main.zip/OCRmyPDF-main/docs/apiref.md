% SPDX-FileCopyrightText: 2022 James R. Barlow
% SPDX-License-Identifier: CC-BY-SA-4.0

# API reference

This page summarizes the rest of the public API. Generally speaking this
should be mainly of interest to plugin developers.

## ocrmypdf.api

```{eval-rst}
.. automodule:: ocrmypdf.api
    :members:
```

## ocrmypdf._options

```{eval-rst}
.. automodule:: ocrmypdf._options
    :members: OcrOptions
```

## ocrmypdf.exceptions

```{eval-rst}
.. automodule:: ocrmypdf.exceptions
    :members:
    :undoc-members:
```

## ocrmypdf.helpers

```{eval-rst}
.. automodule:: ocrmypdf.helpers
    :members:
```

## ocrmypdf.hocrtransform

```{eval-rst}
.. automodule:: ocrmypdf.hocrtransform
    :members:
```

## ocrmypdf.pdfa

```{eval-rst}
.. automodule:: ocrmypdf.pdfa
    :members:
```

## ocrmypdf.quality

```{eval-rst}
.. automodule:: ocrmypdf.quality
    :members:
```

## ocrmypdf.subprocess

```{eval-rst}
.. automodule:: ocrmypdf.subprocess
    :members:
```
