import { Font, Fontkit, Glyph, Subset, TypeFeatures } from '../../types/fontkit.js';

import CustomFontEmbedder, { parseFont } from './CustomFontEmbedder.js';
import PDFHexString from '../objects/PDFHexString.js';
import { Cache, mergeUint8Arrays, toHexStringOfMinLength } from '../../utils/index.js';

/**
 * A note of thanks to the developers of https://github.com/foliojs/pdfkit, as
 * this class borrows from:
 *   https://github.com/devongovett/pdfkit/blob/e71edab0dd4657b5a767804ba86c94c58d01fbca/lib/image/jpeg.coffee
 */
class CustomFontSubsetEmbedder extends CustomFontEmbedder {
  static async for(
    fontkit: Fontkit,
    fontData: Uint8Array,
    customFontName?: string,
    fontFeatures?: TypeFeatures,
  ) {
    const font = parseFont(fontkit, fontData);
    return new CustomFontSubsetEmbedder(font, fontData, customFontName, fontFeatures);
  }

  private readonly subset: Subset;
  private readonly glyphs: Glyph[];
  private readonly glyphIdMap: Map<number, number>;

  private constructor(
    font: Font,
    fontData: Uint8Array,
    customFontName?: string,
    fontFeatures?: TypeFeatures,
  ) {
    super(font, fontData, customFontName, fontFeatures);

    this.subset = this.font.createSubset();
    this.glyphs = [];
    this.glyphCache = Cache.populatedBy(() => this.glyphs);
    this.glyphIdMap = new Map();
  }

  protected registerShapedGlyphs(_glyphs: Glyph[]): void {
    // Subset embedder already tracks used glyphs via `includeGlyph`.
  }

  encodeText(text: string): PDFHexString {
    const glyphs = this.layoutGlyphs(text);
    const hexCodes = Array(glyphs.length);

    for (let idx = 0, len = glyphs.length; idx < len; idx++) {
      const glyph = glyphs[idx];
      const subsetGlyphId = this.subset.includeGlyph(glyph);

      this.glyphs[subsetGlyphId - 1] = glyph;
      this.glyphIdMap.set(glyph.id, subsetGlyphId);

      hexCodes[idx] = toHexStringOfMinLength(subsetGlyphId, 4);
    }

    this.glyphCache.invalidate();
    return PDFHexString.of(hexCodes.join(''));
  }

  protected isCFF(): boolean {
    return (this.subset as any).cff;
  }

  protected glyphId(glyph?: Glyph): number {
    return glyph ? this.glyphIdMap.get(glyph.id)! : -1;
  }

  protected serializeFont(): Promise<Uint8Array> {
    return new Promise((resolve, reject) => {
      if ('encodeStream' in this.subset) {
        const parts: Uint8Array[] = [];
        this.subset
          .encodeStream()
          .on('data', (bytes) => parts.push(bytes))
          .on('end', () => resolve(mergeUint8Arrays(parts)))
          .on('error' as any, (err) => reject(err));
      } else if ('encode' in this.subset) {
        try {
          resolve(this.subset.encode());
        } catch (err) {
          reject(err);
        }
      } else {
        reject(new Error('Subset does not have an encode method'));
      }
    });
  }
}

export default CustomFontSubsetEmbedder;
