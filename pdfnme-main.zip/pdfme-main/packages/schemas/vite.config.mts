import { readFileSync } from 'node:fs';
import { builtinModules } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageJson = JSON.parse(readFileSync(resolve(__dirname, 'package.json'), 'utf8')) as {
  dependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
};

const builtinModuleSet = new Set([
  ...builtinModules,
  ...builtinModules.map((moduleName) => `node:${moduleName}`),
]);
const packageDependencies = [
  ...Object.keys(packageJson.dependencies ?? {}),
  ...Object.keys(packageJson.peerDependencies ?? {}),
];

const isExternal = (id: string) => {
  if (id.startsWith('air-datepicker/locale/')) {
    return false;
  }

  return (
    builtinModuleSet.has(id) ||
    packageDependencies.some((dependency) => id === dependency || id.startsWith(`${dependency}/`))
  );
};

export default defineConfig({
  build: {
    lib: {
      entry: {
        builtins: resolve(__dirname, 'src/builtins.ts'),
        dynamicLayout: resolve(__dirname, 'src/dynamicLayout.ts'),
        index: resolve(__dirname, 'src/index.ts'),
        lists: resolve(__dirname, 'src/lists.ts'),
        tables: resolve(__dirname, 'src/tables.ts'),
        texts: resolve(__dirname, 'src/texts.ts'),
        types: resolve(__dirname, 'src/types.ts'),
        utils: resolve(__dirname, 'src/utils.ts'),
      },
      fileName: (_, entryName) => `${entryName}.js`,
      formats: ['es'],
    },
    minify: false,
    outDir: 'dist',
    rollupOptions: { external: isExternal },
    sourcemap: true,
    target: 'es2020',
  },
});
