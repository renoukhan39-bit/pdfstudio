import * as fontkit from 'fontkit';
import type { Font as FontKitFont } from 'fontkit';
import {
  b64toUint8Array,
  mm2pt,
  pt2mm,
  pt2px,
  Font,
  getFallbackFontName,
  getDefaultFont,
  DEFAULT_FONT_NAME,
  isUrlSafeToFetch,
} from '@pdfme/common';
import { parseFont } from '@pdfme/pdf-lib';
import type { DYNAMIC_FONT_SIZE_FIT, TextSchema, FontWidthCalcValues } from './types.js';
import { getBoxContentArea } from '../box.js';
import { splitParagraphs, toLegacySplitLines, wrapText, type WrapLine } from './wrap.js';
import {
  DEFAULT_FONT_SIZE,
  DEFAULT_CHARACTER_SPACING,
  DEFAULT_LINE_HEIGHT,
  FONT_SIZE_ADJUSTMENT,
  DEFAULT_DYNAMIC_FIT,
  DYNAMIC_FIT_HORIZONTAL,
  DYNAMIC_FIT_VERTICAL,
  VERTICAL_ALIGN_TOP,
  LINE_END_FORBIDDEN_CHARS,
  LINE_START_FORBIDDEN_CHARS,
} from './constants.js';

export const getBrowserVerticalFontAdjustments = (
  fontKitFont: FontKitFont,
  fontSize: number,
  lineHeight: number,
  verticalAlignment: string,
) => {
  const { ascent, descent, unitsPerEm } = fontKitFont;

  // Fonts have a designed line height that the browser renders when using `line-height: normal`
  const fontBaseLineHeight = (ascent - descent) / unitsPerEm;

  // For vertical alignment top
  // To achieve consistent positioning between browser and PDF, we apply the difference between
  // the font's actual height and the font size in pixels.
  // Browsers middle the font within this height, so we only need half of it to apply to the top.
  // This means the font renders a bit lower in the browser, but achieves PDF alignment
  const topAdjustment = (fontBaseLineHeight * fontSize - fontSize) / 2;

  if (verticalAlignment === VERTICAL_ALIGN_TOP) {
    return { topAdj: pt2px(topAdjustment), bottomAdj: 0 };
  }

  // For vertical alignment bottom and middle
  // When browsers render text in a non-form element (such as a <div>), some of the text may be
  // lowered below and outside the containing element if the line height used is less than
  // the base line-height of the font.
  // This behaviour does not happen in a <textarea> though, so we need to adjust the positioning
  // for consistency between editing and viewing to stop text jumping up and down.
  // This portion of text is half of the difference between the base line height and the used
  // line height. If using the same or higher line-height than the base font, then line-height
  // takes over in the browser and this adjustment is not needed.
  // Unlike the top adjustment - this is only driven by browser behaviour, not PDF alignment.
  let bottomAdjustment = 0;
  if (lineHeight < fontBaseLineHeight) {
    bottomAdjustment = ((fontBaseLineHeight - lineHeight) * fontSize) / 2;
  }

  return { topAdj: 0, bottomAdj: pt2px(bottomAdjustment) };
};

export const getFontDescentInPt = (fontKitFont: FontKitFont, fontSize: number) => {
  const { descent, unitsPerEm } = fontKitFont;

  return (descent / unitsPerEm) * fontSize;
};

export const heightOfFontAtSize = (fontKitFont: FontKitFont, fontSize: number) => {
  const { ascent, descent, bbox, unitsPerEm } = fontKitFont;

  const scale = 1000 / unitsPerEm;
  const yTop = (ascent || bbox.maxY) * scale;
  const yBottom = (descent || bbox.minY) * scale;

  let height = yTop - yBottom;
  height -= Math.abs(descent * scale) || 0;

  return (height / 1000) * fontSize;
};

/**
 * First-line height uses font metrics (including empty leading lines).
 * Later lines use the nominal font size. Shared by plain and Markdown.
 */
export const getLineBoxHeightPt = (
  fontSize: number,
  isFirstLine: boolean,
  lineFonts: readonly FontKitFont[],
  fallbackFont: FontKitFont,
) => {
  if (!isFirstLine) return fontSize;
  const fonts = lineFonts.length > 0 ? lineFonts : [fallbackFont];
  return Math.max(...fonts.map((font) => heightOfFontAtSize(font, fontSize)));
};

export const fitDynamicFontSize = ({
  startSize,
  setting,
  boxWidth,
  boxHeight,
  calculateConstraints,
}: {
  startSize: number;
  setting: { min: number; max: number; fit?: DYNAMIC_FONT_SIZE_FIT };
  boxWidth: number;
  boxHeight: number;
  calculateConstraints: (size: number) => { totalWidthInMm: number; totalHeightInMm: number };
}) => {
  if (setting.max < setting.min) return startSize;

  let dynamicFontSize = startSize;
  if (dynamicFontSize < setting.min) {
    dynamicFontSize = setting.min;
  } else if (dynamicFontSize > setting.max) {
    dynamicFontSize = setting.max;
  }

  const dynamicFontFit = setting.fit ?? DEFAULT_DYNAMIC_FIT;

  const shouldFontGrowToFit = (totalWidthInMm: number, totalHeightInMm: number) => {
    if (dynamicFontSize >= setting.max) {
      return false;
    }
    if (dynamicFontFit === DYNAMIC_FIT_HORIZONTAL) {
      return totalWidthInMm < boxWidth;
    }
    return totalHeightInMm < boxHeight;
  };

  const shouldFontShrinkToFit = (totalWidthInMm: number, totalHeightInMm: number) => {
    if (dynamicFontSize <= setting.min || dynamicFontSize <= 0) {
      return false;
    }
    return totalWidthInMm > boxWidth || totalHeightInMm > boxHeight;
  };

  let { totalWidthInMm, totalHeightInMm } = calculateConstraints(dynamicFontSize);

  while (shouldFontGrowToFit(totalWidthInMm, totalHeightInMm)) {
    dynamicFontSize += FONT_SIZE_ADJUSTMENT;
    const { totalWidthInMm: newWidth, totalHeightInMm: newHeight } =
      calculateConstraints(dynamicFontSize);

    if (newHeight < boxHeight) {
      totalWidthInMm = newWidth;
      totalHeightInMm = newHeight;
    } else {
      dynamicFontSize -= FONT_SIZE_ADJUSTMENT;
      break;
    }
  }

  while (shouldFontShrinkToFit(totalWidthInMm, totalHeightInMm)) {
    dynamicFontSize -= FONT_SIZE_ADJUSTMENT;
    ({ totalWidthInMm, totalHeightInMm } = calculateConstraints(dynamicFontSize));
  }

  return dynamicFontSize;
};

const calculateCharacterSpacing = (textContent: string, textCharacterSpacing: number) => {
  return (textContent.length - 1) * textCharacterSpacing;
};

const TEXT_WIDTH_CACHE_LIMIT = 5000;
const textWidthCache = new WeakMap<FontKitFont, Map<string, number>>();

const getTextWidthCache = (fontKitFont: FontKitFont) => {
  let cache = textWidthCache.get(fontKitFont);
  if (!cache) {
    cache = new Map<string, number>();
    textWidthCache.set(fontKitFont, cache);
  }
  return cache;
};

export const widthOfTextAtSize = (
  text: string,
  fontKitFont: FontKitFont,
  fontSize: number,
  characterSpacing: number,
) => {
  const cache = getTextWidthCache(fontKitFont);
  const cacheKey = `${fontSize}\0${characterSpacing}\0${text}`;
  const cachedWidth = cache.get(cacheKey);
  if (cachedWidth !== undefined) {
    return cachedWidth;
  }

  const { glyphs } = fontKitFont.layout(text);
  const scale = 1000 / fontKitFont.unitsPerEm;
  const standardWidth =
    glyphs.reduce((totalWidth, glyph) => totalWidth + glyph.advanceWidth * scale, 0) *
    (fontSize / 1000);
  const width = standardWidth + calculateCharacterSpacing(text, characterSpacing);

  if (cache.size >= TEXT_WIDTH_CACHE_LIMIT) {
    cache.clear();
  }
  cache.set(cacheKey, width);

  return width;
};

const getFallbackFont = (font: Font) => {
  const fallbackFontName = getFallbackFontName(font);
  return font[fallbackFontName];
};

const getCacheKey = (fontName: string) => `getFontKitFont-${fontName}`;
type FontKitFontCacheValue = fontkit.Font | Promise<fontkit.Font>;
type PdfLibFontkit = Parameters<typeof parseFont>[0];

export const fetchRemoteFontData = async (url: string): Promise<ArrayBuffer> => {
  if (!isUrlSafeToFetch(url)) {
    throw Error(
      '[@pdfme/schemas] Invalid or unsafe URL for font data. Only http: and https: URLs pointing to public hosts are allowed.',
    );
  }

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return await response.arrayBuffer();
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw Error(`[@pdfme/schemas] Failed to fetch remote font data from ${url}. ${reason}`);
  }
};

export const getFontKitFont = async (
  fontName: string | undefined,
  font: Font,
  _cache: Map<string | number, fontkit.Font>,
) => {
  const fntNm = fontName || getFallbackFontName(font);
  const cacheKey = getCacheKey(fntNm);
  const fontCache = _cache as Map<string | number, FontKitFontCacheValue>;
  const cachedFont = fontCache.get(cacheKey);
  if (cachedFont) {
    return await cachedFont;
  }

  const currentFont = font[fntNm] || getFallbackFont(font) || getDefaultFont()[DEFAULT_FONT_NAME];
  const fontKitFontPromise = (async () => {
    let fontData = currentFont.data;
    if (typeof fontData === 'string') {
      if (fontData.startsWith('http')) {
        fontData = await fetchRemoteFontData(fontData);
      } else {
        fontData = b64toUint8Array(fontData);
      }
    }

    // Parsed with pdf-lib's cache, which embedding the font reuses: bytes given as an ArrayBuffer
    // or Uint8Array are parsed once across renders (strings are decoded, so parsed, per render).
    // Byte data reaches this synchronously, so concurrent renders share the parse too.
    const fontBytes = fontData instanceof Uint8Array ? fontData : new Uint8Array(fontData);
    return parseFont(fontkit as unknown as PdfLibFontkit, fontBytes) as unknown as fontkit.Font;
  })();
  fontCache.set(cacheKey, fontKitFontPromise);

  try {
    const fontKitFont = await fontKitFontPromise;
    fontCache.set(cacheKey, fontKitFont);
    return fontKitFont;
  } catch (error) {
    if (fontCache.get(cacheKey) === fontKitFontPromise) {
      fontCache.delete(cacheKey);
    }
    throw error;
  }
};

const isTextExceedingBoxWidth = (text: string, calcValues: FontWidthCalcValues) => {
  const { font, fontSize, characterSpacing, boxWidthInPt } = calcValues;
  const textWidth = widthOfTextAtSize(text, font, fontSize, characterSpacing);
  return textWidth > boxWidthInPt;
};

/**
 * Incrementally checks the current line for its real length
 * and returns the position where it exceeds the box width.
 * Returns `null` to indicate if textLine is shorter than the available box.
 */
const getOverPosition = (textLine: string, calcValues: FontWidthCalcValues) => {
  for (let i = 0; i <= textLine.length; i++) {
    if (isTextExceedingBoxWidth(textLine.slice(0, i + 1), calcValues)) {
      return i;
    }
  }

  return null;
};

/**
 * Line breakable chars depend on the language and writing system.
 * Western writing systems typically use spaces and hyphens as line breakable chars.
 * Other writing systems often break on word boundaries so the following
 * does not negatively impact them.
 * However, this might need to be revisited for broader language support.
 */
const isLineBreakableChar = (char: string) => {
  const lineBreakableChars = [' ', '-', '\u2014', '\u2013'];
  return lineBreakableChars.includes(char);
};

/**
 * Gets the position of the split. Splits the exceeding line at
 * the last breakable char prior to it exceeding the bounding box width.
 */
const getSplitPosition = (textLine: string, calcValues: FontWidthCalcValues) => {
  const overPos = getOverPosition(textLine, calcValues);
  if (overPos === null) return textLine.length; // input line is shorter than the available space

  if (textLine[overPos] === ' ') {
    // if the character immediately beyond the boundary is a space, split
    return overPos;
  }

  let overPosTmp = overPos - 1;
  while (overPosTmp >= 0) {
    if (isLineBreakableChar(textLine[overPosTmp])) {
      return overPosTmp + 1;
    }
    overPosTmp--;
  }

  // For very long lines with no breakable chars use the original overPos
  return overPos;
};

/**
 * Recursively splits the line at getSplitPosition.
 * If there is some leftover, split the rest again in the same manner.
 */
export const getSplittedLines = (textLine: string, calcValues: FontWidthCalcValues): string[] => {
  const splitPos = getSplitPosition(textLine, calcValues);
  const splittedLine = textLine.substring(0, splitPos).trimEnd();
  const rest = textLine.substring(splitPos).trimStart();

  if (rest === textLine) {
    // if we went so small that we want to split on the first char
    // then end recursion to avoid infinite loop
    return [textLine];
  }

  if (rest.length === 0) {
    // end recursion if there is no leftover
    return [splittedLine];
  }

  return [splittedLine, ...getSplittedLines(rest, calcValues)];
};

/**
 * If using dynamic font size, iteratively increment or decrement the
 * font size to fit the containing box.
 * Calculating space usage involves splitting lines where they exceed
 * the box width based on the proposed size.
 */
export const calculateDynamicFontSize = ({
  textSchema,
  fontKitFont,
  value,
  startingFontSize,
}: {
  textSchema: TextSchema;
  fontKitFont: FontKitFont;
  value: string;
  startingFontSize?: number | undefined;
}) => {
  const {
    fontSize: schemaFontSize,
    dynamicFontSize: dynamicFontSizeSetting,
    characterSpacing: schemaCharacterSpacing,
    lineHeight = DEFAULT_LINE_HEIGHT,
  } = textSchema;
  const { width: boxWidth, height: boxHeight } = getBoxContentArea(textSchema);
  const fontSize = startingFontSize || schemaFontSize || DEFAULT_FONT_SIZE;
  if (!dynamicFontSizeSetting) return fontSize;
  if (dynamicFontSizeSetting.max < dynamicFontSizeSetting.min) return fontSize;

  const characterSpacing = schemaCharacterSpacing ?? DEFAULT_CHARACTER_SPACING;
  const paragraphs = splitParagraphs(value);
  const dynamicFontFit = dynamicFontSizeSetting.fit ?? DEFAULT_DYNAMIC_FIT;

  return fitDynamicFontSize({
    startSize: fontSize,
    setting: dynamicFontSizeSetting,
    boxWidth,
    boxHeight,
    calculateConstraints: (size) => {
      let totalWidthInMm = 0;
      let totalHeightInMm = 0;
      const boxWidthInPt = mm2pt(boxWidth);
      const lines = wrapText(
        value,
        (text) =>
          text.length === 0 ? 0 : widthOfTextAtSize(text, fontKitFont, size, characterSpacing),
        boxWidthInPt,
      );

      lines.forEach((line, lineIndex) => {
        if (dynamicFontFit === DYNAMIC_FIT_VERTICAL) {
          const textWidth = widthOfTextAtSize(line.text, fontKitFont, size, characterSpacing);
          totalWidthInMm = Math.max(totalWidthInMm, pt2mm(textWidth));
        }

        totalHeightInMm += pt2mm(
          getLineBoxHeightPt(size, lineIndex === 0, [fontKitFont], fontKitFont) * lineHeight,
        );
      });

      if (dynamicFontFit === DYNAMIC_FIT_HORIZONTAL) {
        paragraphs.forEach((paragraph) => {
          const textWidth = widthOfTextAtSize(paragraph, fontKitFont, size, characterSpacing);
          totalWidthInMm = Math.max(totalWidthInMm, pt2mm(textWidth));
        });
      }

      return { totalWidthInMm, totalHeightInMm };
    },
  });
};

const measureTextWidth = (
  text: string,
  fontKitFont: fontkit.Font,
  fontSize: number,
  characterSpacing: number,
) => (text.length === 0 ? 0 : widthOfTextAtSize(text, fontKitFont, fontSize, characterSpacing));

export const wrapTextToSize = (arg: {
  value: string;
  characterSpacing: number;
  boxWidthInPt: number;
  fontSize: number;
  fontKitFont: fontkit.Font;
}): WrapLine[] => {
  const { value, characterSpacing, fontSize, fontKitFont, boxWidthInPt } = arg;
  return wrapText(
    value,
    (text) => measureTextWidth(text, fontKitFont, fontSize, characterSpacing),
    boxWidthInPt,
  );
};

/**
 * Facade over the shared wrap engine. Converts structured `{ text, hardBreak }`
 * lines into the historical `\n`-suffixed strings used by PDF / tables / lists.
 * Viewer should call `wrapTextToSize` instead — see `toLegacySplitLines`.
 */
export const splitTextToSize = (arg: {
  value: string;
  characterSpacing: number;
  boxWidthInPt: number;
  fontSize: number;
  fontKitFont: fontkit.Font;
}) => toLegacySplitLines(wrapTextToSize(arg));
export const isFirefox = () => navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
//
// 日本語禁則処理
//
// https://www.morisawa.co.jp/blogs/MVP/8760
//
// 行頭禁則
export const filterStartJP = (lines: string[]): string[] => {
  const filtered: string[] = [];
  let charToAppend: string | null = null;

  lines
    .slice()
    .reverse()
    .forEach((line) => {
      if (line.trim().length === 0) {
        filtered.push('');
      } else {
        const charAtStart: string = line.charAt(0);
        if (LINE_START_FORBIDDEN_CHARS.includes(charAtStart)) {
          if (line.trim().length === 1) {
            filtered.push(line);
            charToAppend = null;
          } else {
            if (charToAppend) {
              filtered.push(line.slice(1) + charToAppend);
            } else {
              filtered.push(line.slice(1));
            }
            charToAppend = charAtStart;
          }
        } else {
          if (charToAppend) {
            filtered.push(line + charToAppend);
            charToAppend = null;
          } else {
            filtered.push(line);
          }
        }
      }
    });

  if (charToAppend) {
    // Handle the case where filtered might be empty
    const firstItem = filtered.length > 0 ? filtered[0] : '';
    // Ensure we're concatenating strings
    const combinedItem = String(charToAppend) + String(firstItem);
    return [combinedItem, ...filtered.slice(1)].reverse();
  } else {
    return filtered.reverse();
  }
};

// 行末禁則
export const filterEndJP = (lines: string[]): string[] => {
  const filtered: string[] = [];
  let charToPrepend: string | null = null;

  lines.forEach((line) => {
    if (line.trim().length === 0) {
      filtered.push('');
    } else {
      const chartAtEnd = line.slice(-1);

      if (LINE_END_FORBIDDEN_CHARS.includes(chartAtEnd)) {
        if (line.trim().length === 1) {
          filtered.push(line);
          charToPrepend = null;
        } else {
          if (charToPrepend) {
            filtered.push(charToPrepend + line.slice(0, -1));
          } else {
            filtered.push(line.slice(0, -1));
          }
          charToPrepend = chartAtEnd;
        }
      } else {
        if (charToPrepend) {
          filtered.push(charToPrepend + line);
          charToPrepend = null;
        } else {
          filtered.push(line);
        }
      }
    }
  });

  if (charToPrepend) {
    // Handle the case where filtered might be empty
    const lastItem = filtered.length > 0 ? filtered[filtered.length - 1] : '';
    // Ensure we're concatenating strings
    const combinedItem = String(lastItem) + String(charToPrepend);
    return [...filtered.slice(0, -1), combinedItem];
  } else {
    return filtered;
  }
};
