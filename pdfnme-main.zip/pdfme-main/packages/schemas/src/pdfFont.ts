import { PDFFont, PDFDocument } from '@pdfme/pdf-lib';
import { Font } from '@pdfme/common';
import { fetchRemoteFontData } from './text/helper.js';

type PdfFontCache = Record<string, Promise<PDFFont>>;

const PDF_FONT_CACHE_KEY = 'schemas-pdf-font-cache';

const getPdfFontCache = (_cache: Map<string | number, unknown>): PdfFontCache => {
  let pdfFontCache = _cache.get(PDF_FONT_CACHE_KEY) as PdfFontCache | undefined;
  if (!pdfFontCache) {
    pdfFontCache = {};
    _cache.set(PDF_FONT_CACHE_KEY, pdfFontCache);
  }

  return pdfFontCache;
};

export const embedAndGetFont = (arg: {
  pdfDoc: PDFDocument;
  font: Font;
  fontName: string;
  _cache: Map<string | number, unknown>;
}) => {
  const { pdfDoc, font, fontName, _cache } = arg;
  const pdfFontCache = getPdfFontCache(_cache);
  const cachedFont = pdfFontCache[fontName];
  if (cachedFont) {
    return cachedFont;
  }

  const pdfFontPromise = (async () => {
    const fontValue = font[fontName];
    if (!fontValue) {
      throw new Error(`[@pdfme/schemas] Font "${fontName}" is not found.`);
    }

    let fontData = fontValue.data;
    if (typeof fontData === 'string' && fontData.startsWith('http')) {
      fontData = await fetchRemoteFontData(fontData);
    }
    return pdfDoc.embedFont(fontData, {
      subset: typeof fontValue.subset === 'undefined' ? true : fontValue.subset,
    });
  })();

  // Attach a no-op rejection handler so that if a caller creates this promise but
  // unwinds before awaiting it (e.g. an earlier await throws for the same broken
  // font data), the rejection doesn't escape as an unhandledRejection and crash
  // the process (#1636). Callers that await the promise still receive the error.
  pdfFontPromise.catch(() => {});
  pdfFontCache[fontName] = pdfFontPromise;
  return pdfFontPromise;
};
