import globals from "globals";

import import_ from "eslint-plugin-import-x";
import jasmine from "eslint-plugin-jasmine";
import jsdoc from "eslint-plugin-jsdoc";
import json from "@eslint/json";
import noUnsanitized from "eslint-plugin-no-unsanitized";
import perfectionist from "eslint-plugin-perfectionist";
import preferMathClamp from "./external/eslint_plugins/prefer-math-clamp.mjs";
import prettierRecommended from "eslint-plugin-prettier/recommended";
import regexpPlugin from "eslint-plugin-regexp";
import unicorn from "eslint-plugin-unicorn";

const jsFiles = folder => {
  const prefix = folder === "." ? "" : folder + "/";
  return [prefix + "**/*.js", prefix + "**/*.jsm", prefix + "**/*.mjs"];
};

// Include all files referenced in extensions/chromium/background.js
const chromiumExtensionServiceWorkerFiles = [
  "extensions/chromium/extension-router.js",
  "extensions/chromium/options/migration.js",
  "extensions/chromium/pdfHandler.js",
  "extensions/chromium/preserve-referer.js",
  "extensions/chromium/suppress-update.js",
  "extensions/chromium/telemetry.js",
];

export default [
  {
    ignores: [
      "package-lock.json",
      "**/build/",
      "**/l10n/",
      "**/docs/",
      "**/node_modules/",
      "external/bcmaps/",
      "external/brotli/",
      "external/builder/fixtures/",
      "external/builder/fixtures_babel/",
      "external/hellbox/",
      "external/openjpeg/",
      "external/qcms/",
      "external/jbig2/",
      "external/quickjs/",
      "test/stats/results/",
      "test/tmp/",
      "test/pdfs/",
      "web/locale/",
      "web/wasm/",
      "**/*~/",
      ".{claude,codex,cursor}/",
    ],
  },

  /* ======================================================================== *\
                             Base configuration
  \* ======================================================================== */

  prettierRecommended,
  {
    files: jsFiles("."),
    plugins: regexpPlugin.configs["flat/recommended"].plugins,
    rules: {
      ...regexpPlugin.configs["flat/recommended"].rules,
      "regexp/no-legacy-features": "off",
      "regexp/no-octal": "error",
      "regexp/no-potentially-useless-backreference": "error",
      "regexp/no-standalone-backslash": "error",
      "regexp/no-super-linear-move": "error",
      "regexp/optimal-lookaround-quantifier": "error",
      "regexp/prefer-escape-replacement-dollar-char": "error",
      "regexp/prefer-regexp-exec": "error",
    },
  },
  {
    files: ["**/*.json", "**/.*.json"],
    language: "json/json",
    ...json.configs.recommended,
  },
  {
    files: jsFiles("."),
    ignores: chromiumExtensionServiceWorkerFiles,
    languageOptions: {
      globals: globals.browser,
    },
  },
  {
    files: jsFiles("."),

    plugins: {
      import: import_.flatConfigs.recommended.plugins["import-x"],
      json,
      "no-unsanitized": noUnsanitized,
      perfectionist,
      "prefer-math-clamp": preferMathClamp,
      unicorn,
    },

    settings: {
      "import-x/resolver-next": [
        import_.createNodeResolver({
          alias: {
            "pdfjs-lib": [import.meta.dirname + "/web/pdfjs.js"],
            pdfjs: [import.meta.dirname + "/src"],
          },
        }),
      ],
    },

    languageOptions: {
      globals: {
        ...globals.worker,
        PDFJSDev: "readonly",
        __raw_import__: "readonly",
        __eager_import__: "readonly",
      },

      ecmaVersion: 2025,
      sourceType: "module",
    },

    rules: {
      "import/export": "error",
      "import/exports-last": "error",
      "import/extensions": ["error", "always", { ignorePackages: true }],
      "import/first": "error",
      "import/named": "error",
      "import/no-cycle": "error",
      "import/no-empty-named-blocks": "error",
      "import/no-commonjs": "error",
      "import/no-mutable-exports": "error",
      "import/no-restricted-paths": [
        "error",
        {
          zones: [
            {
              target: "./web",
              from: "./src",
              except: ["./pdf.worker.js"],
            },
          ],
        },
      ],
      "import/no-self-import": "error",
      "import/no-unresolved": [
        "error",
        {
          ignore: [
            "^display-",
            "^web-",
            "^@csstools/postcss-light-dark-function$",
            "^fluent-bundle$",
            "^fluent-dom$",
            "^pdfjs-dist(/|$)",
            "^postcss-dir-pseudo-class$",
            "^postcss-nesting$",
            "^postcss-values-parser$",
            "^stylelint$",
            // See https://github.com/firebase/firebase-admin-node/discussions/1359.
            "^eslint-plugin-perfectionist$",
          ],
        },
      ],
      "no-unsanitized/method": "error",
      "no-unsanitized/property": "error",
      "perfectionist/sort-exports": "error",
      "perfectionist/sort-named-exports": "error",
      "unicorn/no-abusive-eslint-disable": "error",
      "unicorn/no-array-reduce": ["error", { allowSimpleOperations: true }],
      "unicorn/no-console-spaces": "error",
      "unicorn/no-incorrect-query-selector": "error",
      "unicorn/no-instanceof-builtins": "error",
      "unicorn/no-invalid-remove-event-listener": "error",
      "unicorn/no-multiple-promise-resolver-calls": "error",
      "unicorn/no-new-buffer": "error",
      "unicorn/no-single-promise-in-promise-methods": "error",
      "unicorn/no-typeof-undefined": ["error", { checkGlobalVariables: false }],
      "unicorn/no-unnecessary-array-flat-depth": "error",
      "unicorn/no-unnecessary-array-splice-count": "error",
      "unicorn/no-unnecessary-slice-end": "error",
      "unicorn/no-useless-collection-argument": "error",
      "unicorn/no-useless-promise-resolve-reject": "error",
      "unicorn/no-useless-spread": "error",
      "unicorn/prefer-array-find": "error",
      "unicorn/prefer-array-flat": "error",
      "unicorn/prefer-array-flat-map": "error",
      "unicorn/prefer-array-index-of": "error",
      "unicorn/prefer-array-some": "error",
      "unicorn/prefer-at": "error",
      "unicorn/prefer-class-fields": "error",
      "unicorn/prefer-classlist-toggle": "error",
      "unicorn/prefer-combined-guards": "error",
      "unicorn/prefer-date-now": "error",
      "unicorn/prefer-dom-node-append": "error",
      "unicorn/prefer-dom-node-remove": "error",
      "unicorn/prefer-import-meta-properties": "error",
      "unicorn/prefer-includes": "error",
      "unicorn/logical-assignment-operators": [
        "error",
        "always",
        { enforceForIfStatements: true },
      ],
      "unicorn/prefer-logical-operator-over-ternary": "error",
      "unicorn/prefer-modern-dom-apis": "error",
      "unicorn/prefer-modern-math-apis": "error",
      "unicorn/prefer-negative-index": "error",
      "unicorn/prefer-optional-catch-binding": "error",
      "unicorn/prefer-regexp-test": "error",
      "unicorn/prefer-set-methods": "error",
      "unicorn/prefer-short-arrow-method": "error",
      "unicorn/prefer-single-call": "error",
      "unicorn/prefer-smaller-scope": "error",
      "unicorn/prefer-string-replace-all": "error",
      "unicorn/prefer-string-starts-ends-with": "error",
      "unicorn/prefer-ternary": ["error", "only-single-line"],
      "unicorn/throw-new-error": "error",

      "prefer-math-clamp/prefer-math-clamp": "error",

      // Possible errors
      "for-direction": "error",
      "getter-return": "error",
      "no-async-promise-executor": "error",
      "no-cond-assign": ["error", "except-parens"],
      "no-constant-condition": ["error", { checkLoops: false }],
      "no-debugger": "error",
      "no-dupe-args": "error",
      "no-dupe-else-if": "error",
      "no-dupe-keys": "error",
      "no-duplicate-case": "error",
      "no-empty": ["error", { allowEmptyCatch: true }],
      "no-empty-character-class": "error",
      "no-ex-assign": "error",
      "no-extra-boolean-cast": "error",
      "no-func-assign": "error",
      "no-inner-declarations": ["error", "functions"],
      "no-invalid-regexp": "error",
      "no-irregular-whitespace": "error",
      "no-loss-of-precision": "error",
      "no-obj-calls": "error",
      "no-promise-executor-return": "error",
      "no-regex-spaces": "error",
      "no-setter-return": "error",
      "no-sparse-arrays": "error",
      "no-template-curly-in-string": "error",
      "no-unexpected-multiline": "error",
      "no-unreachable": "error",
      "no-unsafe-finally": "error",
      "no-unsafe-negation": "error",
      "no-unsafe-optional-chaining": [
        "error",
        { disallowArithmeticOperators: true },
      ],
      "no-unused-private-class-members": "error",
      "use-isnan": ["error", { enforceForIndexOf: true }],
      "valid-typeof": ["error", { requireStringLiterals: true }],

      // Best Practices
      "accessor-pairs": [
        "error",
        { setWithoutGet: true, enforceForClassMembers: true },
      ],
      "consistent-return": "error",
      curly: ["error", "all"],
      "default-case-last": "error",
      "dot-notation": "error",
      eqeqeq: ["error", "always"],
      "grouped-accessor-pairs": ["error", "getBeforeSet"],
      "no-alert": "error",
      "no-caller": "error",
      "no-else-return": "error",
      "no-empty-pattern": "error",
      "no-eval": "error",
      "no-extend-native": "error",
      "no-extra-bind": "error",
      "no-extra-label": "error",
      "no-fallthrough": "error",
      "no-floating-decimal": "error",
      "no-global-assign": "error",
      "no-implied-eval": "error",
      "no-iterator": "error",
      "no-lone-blocks": "error",
      "no-lonely-if": "error",
      "no-multi-str": "error",
      "no-new": "error",
      "no-new-func": "error",
      "no-new-symbol": "error",
      "no-new-wrappers": "error",
      "no-octal-escape": "error",
      "no-octal": "error",
      "no-redeclare": "error",
      "no-return-await": "error",
      "no-self-assign": "error",
      "no-self-compare": "error",
      "no-throw-literal": "error",
      "no-unused-expressions": "error",
      "no-unused-labels": "error",
      "no-useless-call": "error",
      "no-useless-catch": "error",
      "no-useless-concat": "error",
      "no-useless-escape": "error",
      "no-useless-return": "error",
      "prefer-object-has-own": "error",
      "prefer-promise-reject-errors": "error",
      "prefer-spread": "error",
      radix: "error",
      "wrap-iife": ["error", "any"],
      yoda: ["error", "never", { exceptRange: true }],

      // Strict Mode
      strict: ["off", "global"],

      // Variables
      "no-delete-var": "error",
      "no-label-var": "error",
      "no-shadow": "error",
      "no-shadow-restricted-names": "error",
      "no-undef-init": "error",
      "no-undef": ["error", { typeof: true }],
      "no-unused-vars": ["error", { vars: "all", args: "none" }],
      "no-use-before-define": [
        "error",
        { functions: false, classes: false, variables: false },
      ],

      // Stylistic Issues
      "lines-between-class-members": ["error", "always"],
      "max-len": ["error", { code: 1000, comments: 80, ignoreUrls: true }],
      "new-cap": [
        "error",
        {
          newIsCap: true,
          newIsCapExceptionPattern: "constructor",
          capIsNew: false,
        },
      ],
      "no-array-constructor": "error",
      "no-multiple-empty-lines": ["error", { max: 1, maxEOF: 0, maxBOF: 1 }],
      "no-nested-ternary": "error",
      "no-new-object": "error",
      "no-restricted-syntax": [
        "error",
        {
          selector:
            "BinaryExpression[operator='instanceof'][right.name='Object']",
          message: "Use `typeof` rather than `instanceof Object`.",
        },
        {
          selector: "MemberExpression[property.name='hasOwnProperty']",
          message:
            "Use `Object.hasOwn` rather than `Object.prototype.hasOwnProperty`.",
        },
        {
          selector: "CallExpression[callee.name='assert'][arguments.length!=2]",
          message: "`assert()` must always be invoked with two arguments.",
        },
        {
          selector: "CallExpression[callee.name='isCmd'][arguments.length<2]",
          message:
            "Use `instanceof Cmd` rather than `isCmd()` with one argument.",
        },
        {
          selector: "CallExpression[callee.name='isDict'][arguments.length<2]",
          message:
            "Use `instanceof Dict` rather than `isDict()` with one argument.",
        },
        {
          selector: "CallExpression[callee.name='isName'][arguments.length<2]",
          message:
            "Use `instanceof Name` rather than `isName()` with one argument.",
        },
        {
          selector:
            "CallExpression[callee.object.name='Math'][callee.property.name=/^(max|min)$/][arguments.length>4]",
          message:
            "Avoid calling `Math.max`/`Math.min` with more than four arguments, since SpiderMonkey doesn't optimize those (nest the calls instead).",
        },
        {
          selector: "NewExpression[callee.name='Cmd']",
          message: "Use `Cmd.get()` rather than `new Cmd()`.",
        },
        {
          selector: "NewExpression[callee.name='Name']",
          message: "Use `Name.get()` rather than `new Name()`.",
        },
        {
          selector: "NewExpression[callee.name='ObjectLoader']",
          message:
            "Use `ObjectLoader.load()` rather than `new ObjectLoader()`.",
        },
        {
          selector: "NewExpression[callee.name='Ref']",
          message: "Use `Ref.get()` rather than `new Ref()`.",
        },
        {
          selector: "ExportNamedDeclaration[declaration]",
          message:
            "Separate the declaration and the export statement, using `export { ... }`.",
        },
        {
          selector: "ExportDefaultDeclaration:has(> :declaration)",
          message:
            "Separate the declaration and the export statement, using `export default <variable name>`.",
        },
      ],
      "no-unneeded-ternary": "error",
      "operator-assignment": "error",
      "prefer-exponentiation-operator": "error",
      "spaced-comment": ["error", "always", { block: { balanced: true } }],

      // ECMAScript 6
      "arrow-body-style": ["error", "as-needed"],
      "constructor-super": "error",
      "no-class-assign": "error",
      "no-const-assign": "error",
      "no-dupe-class-members": "error",
      "no-duplicate-imports": "error",
      "no-this-before-super": "error",
      "no-useless-computed-key": "error",
      "no-useless-constructor": "error",
      "no-useless-rename": "error",
      "no-var": "error",
      "object-shorthand": ["error", "always", { avoidQuotes: true }],
      "prefer-const": "error",
      "require-yield": "error",
      "sort-imports": ["error", { ignoreCase: true }],
      "template-curly-spacing": ["error", "never"],
    },
  },
  {
    files: jsFiles("src"),
    rules: {
      "no-console": "error",
    },
  },

  /* ======================================================================== *\
                                   JSDoc
  \* ======================================================================== */

  {
    files: jsFiles("."),

    plugins: { jsdoc },

    settings: {
      jsdoc: {
        tagNamePreference: { return: "returns" },
      },
    },

    rules: {
      "jsdoc/check-access": "error",
      "jsdoc/check-alignment": "error",
      "jsdoc/check-param-names": "error",
      "jsdoc/check-property-names": "error",
      // `@licstart`/`@licend` are GNU LibreJS tags, used in the license header.
      "jsdoc/check-tag-names": [
        "error",
        { definedTags: ["licend", "licstart"] },
      ],
      "jsdoc/check-template-names": "error",
      "jsdoc/check-types": "error",
      "jsdoc/check-values": "error",
      "jsdoc/empty-tags": "error",
      "jsdoc/escape-inline-tags": "error",
      "jsdoc/implements-on-classes": "error",
      "jsdoc/multiline-blocks": "error",
      "jsdoc/no-bad-blocks": "error",
      "jsdoc/no-blank-block-descriptions": "error",
      "jsdoc/no-blank-blocks": "error",
      "jsdoc/no-multi-asterisks": "error",
      "jsdoc/normalize-see-links": "error",
      "jsdoc/require-asterisk-prefix": "error",
      "jsdoc/require-param-name": "error",
      "jsdoc/require-param-type": "error",
      "jsdoc/require-property": "error",
      "jsdoc/require-property-name": "error",
      "jsdoc/require-property-type": "error",
      "jsdoc/require-returns-check": "error",
      "jsdoc/require-returns-type": "error",
      "jsdoc/require-throws-description": "error",
      "jsdoc/require-throws-type": "error",
      "jsdoc/require-yields-check": "error",
      "jsdoc/require-yields-description": "error",
      "jsdoc/require-yields-type": "error",
      "jsdoc/tag-lines": "error",
      "jsdoc/valid-types": "error",
    },
  },

  /* ======================================================================== *\
                            Test-specific rules
  \* ======================================================================== */

  {
    files: jsFiles("test"),

    plugins: { jasmine },

    languageOptions: {
      globals: {
        ...globals.node,
        ...globals.jasmine,
      },
    },
    rules: {
      ...jasmine.configs.recommended.rules,
      "jasmine/new-line-before-expect": "off",
      "jasmine/new-line-between-declarations": "off",
      "jasmine/no-focused-tests": "error",
      "jasmine/no-pending-tests": "off",
      "jasmine/no-spec-dupes": ["error", "branch"],
      "jasmine/no-suite-dupes": ["error", "branch"],
      "jasmine/prefer-jasmine-matcher": "off",
      "jasmine/prefer-toHaveBeenCalledWith": "off",
    },
  },
  {
    files: jsFiles("web/internal"),
    rules: {
      // The debugger imports `src/` internals directly.
      "import/no-restricted-paths": "off",
    },
  },
  {
    files: jsFiles("test/unit"),
    rules: {
      "no-console": ["error", { allow: ["warn", "error"] }],
    },
  },
  {
    files: jsFiles("test/integration"),
    rules: {
      "no-console": ["error", { allow: ["warn", "error"] }],
      "no-restricted-syntax": [
        "error",
        {
          selector: "CallExpression[callee.name='waitForTimeout']",
          message:
            "`waitForTimeout` can cause intermittent failures and should not be used (see issue #17656 for replacements).",
        },
      ],
    },
  },

  /* ======================================================================== *\
                            External libraries
  \* ======================================================================== */

  {
    files: jsFiles("external"),

    languageOptions: { globals: globals.node },
  },

  /* ======================================================================== *\
                             Examples
  \* ======================================================================== */

  {
    files: jsFiles("examples"),

    languageOptions: {
      globals: {
        pdfjsImageDecoders: false,
        pdfjsLib: false,
        pdfjsViewer: false,
      },
    },
  },
  {
    files: [...jsFiles("examples/node"), ...jsFiles("examples/webpack")],

    languageOptions: { globals: globals.node },
  },

  /* ======================================================================== *\
                            Chromium extension
  \* ======================================================================== */

  {
    files: jsFiles("extensions/chromium"),

    languageOptions: {
      globals: globals.webextensions,
      sourceType: "script",
    },

    rules: {
      "no-var": "off",
    },
  },
  {
    files: chromiumExtensionServiceWorkerFiles,

    languageOptions: {
      globals: globals.serviceworker,
      sourceType: "script",
    },
  },

  /* ======================================================================== *\
                                Other
  \* ======================================================================== */
  {
    files: ["gulpfile.mjs"],
    languageOptions: { globals: globals.node },
  },
];
