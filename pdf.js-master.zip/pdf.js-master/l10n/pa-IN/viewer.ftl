# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Main toolbar buttons (tooltips and alt text for images)

pdfjs-previous-button =
    .title = ਪਿਛਲਾ ਸਫ਼ਾ
pdfjs-previous-button-label = ਪਿੱਛੇ
pdfjs-next-button =
    .title = ਅਗਲਾ ਸਫ਼ਾ
pdfjs-next-button-label = ਅੱਗੇ
# .title: Tooltip for the pageNumber input.
pdfjs-page-input =
    .title = ਸਫ਼ਾ
# Variables:
#   $pagesCount (Number) - the total number of pages in the document
# This string follows an input field with the number of the page currently displayed.
pdfjs-of-pages = { $pagesCount } ਵਿੱਚੋਂ
# Variables:
#   $pageNumber (Number) - the currently visible page
#   $pagesCount (Number) - the total number of pages in the document
pdfjs-page-of-pages = { $pagesCount }) ਵਿੱਚੋਂ ({ $pageNumber }
pdfjs-zoom-out-button =
    .title = ਜ਼ੂਮ ਆਉਟ
pdfjs-zoom-out-button-label = ਜ਼ੂਮ ਆਉਟ
pdfjs-zoom-in-button =
    .title = ਜ਼ੂਮ ਇਨ
pdfjs-zoom-in-button-label = ਜ਼ੂਮ ਇਨ
pdfjs-zoom-select =
    .title = ਜ਼ੂਨ
pdfjs-presentation-mode-button =
    .title = ਪਰਿਜੈਂਟੇਸ਼ਨ ਮੋਡ ਵਿੱਚ ਜਾਓ
pdfjs-presentation-mode-button-label = ਪਰਿਜੈਂਟੇਸ਼ਨ ਮੋਡ
pdfjs-open-file-button =
    .title = ਫਾਈਲ ਨੂੰ ਖੋਲ੍ਹੋ
pdfjs-open-file-button-label = ਖੋਲ੍ਹੋ
pdfjs-print-button =
    .title = ਪਰਿੰਟ
pdfjs-print-button-label = ਪਰਿੰਟ
pdfjs-save-button =
    .title = ਸੰਭਾਲੋ
pdfjs-save-button-label = ਸੰਭਾਲੋ
# Used in Firefox for Android as a tooltip for the download button (“download” is a verb).
pdfjs-download-button =
    .title = ਡਾਊਨਲੋਡ
# Used in Firefox for Android as a label for the download button (“download” is a verb).
# Length of the translation matters since we are in a mobile context, with limited screen estate.
pdfjs-download-button-label = ਡਾਊਨਲੋਡ
pdfjs-bookmark-button =
    .title = ਮੌਜੂਦਾ ਸਫ਼਼ਾ (ਮੌਜੂਦਾ ਸਫ਼ੇ ਤੋਂ URL ਵੇਖੋ)
pdfjs-bookmark-button-label = ਮੌਜੂਦਾ ਸਫ਼਼ਾ

##  Secondary toolbar and context menu

pdfjs-tools-button =
    .title = ਟੂਲ
pdfjs-tools-button-label = ਟੂਲ
pdfjs-first-page-button =
    .title = ਪਹਿਲੇ ਸਫ਼ੇ ਉੱਤੇ ਜਾਓ
pdfjs-first-page-button-label = ਪਹਿਲੇ ਸਫ਼ੇ ਉੱਤੇ ਜਾਓ
pdfjs-last-page-button =
    .title = ਆਖਰੀ ਸਫ਼ੇ ਉੱਤੇ ਜਾਓ
pdfjs-last-page-button-label = ਆਖਰੀ ਸਫ਼ੇ ਉੱਤੇ ਜਾਓ
pdfjs-page-rotate-cw-button =
    .title = ਸੱਜੇ ਦਾਅ ਘੁੰਮਾਓ
pdfjs-page-rotate-cw-button-label = ਸੱਜੇ ਦਾਅ ਘੁੰਮਾਓ
pdfjs-page-rotate-ccw-button =
    .title = ਖੱਬੇ ਦਾਅ ਘੁੰਮਾਓ
pdfjs-page-rotate-ccw-button-label = ਖੱਬੇ ਦਾਅ ਘੁੰਮਾਓ
pdfjs-cursor-text-select-tool-button =
    .title = ਲਿਖਤ ਚੋਣ ਟੂਲ ਸਮਰੱਥ ਕਰੋ
pdfjs-cursor-text-select-tool-button-label = ਲਿਖਤ ਚੋਣ ਟੂਲ
pdfjs-cursor-hand-tool-button =
    .title = ਹੱਥ ਟੂਲ ਸਮਰੱਥ ਕਰੋ
pdfjs-cursor-hand-tool-button-label = ਹੱਥ ਟੂਲ
pdfjs-scroll-page-button =
    .title = ਸਫ਼ਾ ਖਿਸਕਾਉਣ ਨੂੰ ਵਰਤੋਂ
pdfjs-scroll-page-button-label = ਸਫ਼ਾ ਖਿਸਕਾਉਣਾ
pdfjs-scroll-vertical-button =
    .title = ਖੜ੍ਹਵੇਂ ਸਕਰਾਉਣ ਨੂੰ ਵਰਤੋਂ
pdfjs-scroll-vertical-button-label = ਖੜ੍ਹਵਾਂ ਸਰਕਾਉਣਾ
pdfjs-scroll-horizontal-button =
    .title = ਲੇਟਵੇਂ ਸਰਕਾਉਣ ਨੂੰ ਵਰਤੋਂ
pdfjs-scroll-horizontal-button-label = ਲੇਟਵਾਂ ਸਰਕਾਉਣਾ
pdfjs-scroll-wrapped-button =
    .title = ਸਮੇਟੇ ਸਰਕਾਉਣ ਨੂੰ ਵਰਤੋਂ
pdfjs-scroll-wrapped-button-label = ਸਮੇਟਿਆ ਸਰਕਾਉਣਾ
pdfjs-spread-none-button =
    .title = ਸਫ਼ਾ ਫੈਲਾਅ ਵਿੱਚ ਸ਼ਾਮਲ ਨਾ ਹੋਵੋ
pdfjs-spread-none-button-label = ਕੋਈ ਫੈਲਾਅ ਨਹੀਂ
pdfjs-spread-odd-button =
    .title = ਟਾਂਕ ਅੰਕ ਵਾਲੇ ਸਫ਼ਿਆਂ ਨਾਲ ਸ਼ੁਰੂ ਹੋਣ ਵਾਲੇ ਸਫਿਆਂ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਵੋ
pdfjs-spread-odd-button-label = ਟਾਂਕ ਫੈਲਾਅ
pdfjs-spread-even-button =
    .title = ਜਿਸਤ ਅੰਕ ਵਾਲੇ ਸਫ਼ਿਆਂ ਨਾਲ ਸ਼ੁਰੂ ਹੋਣ ਵਾਲੇ ਸਫਿਆਂ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਵੋ
pdfjs-spread-even-button-label = ਜਿਸਤ ਫੈਲਾਅ

## Document properties dialog

pdfjs-document-properties-button =
    .title = …ਦਸਤਾਵੇਜ਼ ਦੀ ਵਿਸ਼ੇਸ਼ਤਾ
pdfjs-document-properties-button-label = …ਦਸਤਾਵੇਜ਼ ਦੀ ਵਿਸ਼ੇਸ਼ਤਾ
pdfjs-document-properties-file-name = ਫਾਈਲ ਦਾ ਨਾਂ:
pdfjs-document-properties-file-size = ਫਾਈਲ ਦਾ ਆਕਾਰ:
# Variables:
#   $kb (Number) - the PDF file size in kilobytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-kb = { NUMBER($kb, maximumSignificantDigits: 3) } KB ({ $b } ਬਾਈਟ)
# Variables:
#   $mb (Number) - the PDF file size in megabytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-mb = { NUMBER($mb, maximumSignificantDigits: 3) } MB ({ $b } ਬਾਈਟ)
pdfjs-document-properties-title = ਟਾਈਟਲ:
pdfjs-document-properties-author = ਲੇਖਕ:
pdfjs-document-properties-subject = ਵਿਸ਼ਾ:
pdfjs-document-properties-keywords = ਸ਼ਬਦ:
pdfjs-document-properties-creation-date = ਬਣਾਉਣ ਦੀ ਮਿਤੀ:
pdfjs-document-properties-modification-date = ਸੋਧ ਦੀ ਮਿਤੀ:
# Variables:
#   $dateObj (Date) - the creation/modification date and time of the PDF file
pdfjs-document-properties-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }
pdfjs-document-properties-creator = ਨਿਰਮਾਤਾ:
pdfjs-document-properties-producer = PDF ਪ੍ਰੋਡਿਊਸਰ:
pdfjs-document-properties-version = PDF ਵਰਜਨ:
pdfjs-document-properties-page-count = ਸਫ਼ੇ ਦੀ ਗਿਣਤੀ:
pdfjs-document-properties-page-size = ਸਫ਼ਾ ਆਕਾਰ:
pdfjs-document-properties-page-size-unit-inches = ਇੰਚ
pdfjs-document-properties-page-size-unit-millimeters = ਮਿਮੀ
pdfjs-document-properties-page-size-orientation-portrait = ਪੋਰਟਰੇਟ
pdfjs-document-properties-page-size-orientation-landscape = ਲੈਂਡਸਕੇਪ
pdfjs-document-properties-page-size-name-a-three = A3
pdfjs-document-properties-page-size-name-a-four = A4
pdfjs-document-properties-page-size-name-letter = ਲੈਟਰ
pdfjs-document-properties-page-size-name-legal = ਕਨੂੰਨੀ

## Variables:
##   $width (Number) - the width of the (current) page
##   $height (Number) - the height of the (current) page
##   $unit (String) - the unit of measurement of the (current) page
##   $name (String) - the name of the (current) page
##   $orientation (String) - the orientation of the (current) page

pdfjs-document-properties-page-size-dimension-string = { $width } × { $height } { $unit } ({ $orientation })
pdfjs-document-properties-page-size-dimension-name-string = { $width } × { $height } { $unit } ({ $name }, { $orientation })

##

# The linearization status of the document; usually called "Fast Web View" in
# English locales of Adobe software.
pdfjs-document-properties-linearized = ਤੇਜ਼ ਵੈੱਬ ਝਲਕ:
pdfjs-document-properties-linearized-yes = ਹਾਂ
pdfjs-document-properties-linearized-no = ਨਹੀਂ
pdfjs-document-properties-close-button = ਬੰਦ ਕਰੋ
pdfjs-digital-signature-properties-view-certificate = ਸਰਟੀਫਿਕੇਟ ਨੂੰ ਵੇਖੋ
# Shown beneath an invalid signature card to explain why verification
# failed. The text comes from NSS (e.g. "Signature integrity has been
# compromised", "PKCS#7 signature could not be parsed") and is not
# itself localized — it is the underlying error message produced by
# the verification backend.
# Variables:
#   $reason (String) - error message describing why the signature
#                      could not be verified.
pdfjs-digital-signature-properties-reason = ਕਾਰਨ: { $reason }
# Variables:
#   $dateObj (Date) - the signing time from the /Sig dict's /M entry.
pdfjs-digital-signature-properties-timestamp = ਸਮਾਂ: { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }
# Variables:
#   $count (Number) - number of nested sub-signatures (one per earlier
#                     incremental revision of the document).
pdfjs-digital-signature-properties-sub-signatures =
    { $count ->
        [one] ਅਧੀਨ-ਦਸਤਖ਼ਤ ({ $count })
       *[other] ਅਧੀਨ-ਦਸਤਖ਼ਤ({ $count })
    }

## Print

pdfjs-print-progress-message = …ਪਰਿੰਟ ਕਰਨ ਲਈ ਦਸਤਾਵੇਜ਼ ਨੂੰ ਤਿਆਰ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ
# Variables:
#   $progress (Number) - percent value
pdfjs-print-progress-percent = { $progress }%
pdfjs-print-progress-close-button = ਰੱਦ ਕਰੋ
pdfjs-printing-not-supported = ਸਾਵਧਾਨ: ਇਹ ਬਰਾਊਜ਼ਰ ਪਰਿੰਟ ਕਰਨ ਲਈ ਪੂਰੀ ਤਰ੍ਹਾਂ ਸਹਾਇਕ ਨਹੀਂ ਹੈ।
pdfjs-printing-not-ready = ਸਾਵਧਾਨ: PDF ਨੂੰ ਪਰਿੰਟ ਕਰਨ ਲਈ ਪੂਰੀ ਤਰ੍ਹਾਂ ਲੋਡ ਨਹੀਂ ਹੈ।

## Tooltips and alt text for side panel toolbar buttons

pdfjs-current-outline-item-button =
    .title = ਮੌੌਜੂਦਾ ਖਾਕਾ ਚੀਜ਼ ਲੱਭੋ
pdfjs-current-outline-item-button-label = ਮੌਜੂਦਾ ਖਾਕਾ ਚੀਜ਼
pdfjs-findbar-button =
    .title = ਦਸਤਾਵੇਜ਼ ਵਿੱਚ ਲੱਭੋ
pdfjs-findbar-button-label = ਲੱਭੋ
pdfjs-additional-layers = ਵਾਧੂ ਪਰਤਾਂ

## Thumbnails panel item (tooltip and alt text for images)

# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-canvas =
    .aria-label = { $page } ਸਫ਼ੇ ਦਾ ਥੰਮਨੇਲ
# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-checkbox1 =
    .title = { $page } ਸਫ਼ੇ ਨੂੰ ਚੁਣੋ
# Variables:
#   $page (Number) - the page number
#   $total (Number) - the number of pages
pdfjs-thumb-page-title1 =
    .title = { $total } ਵਿੱਚੋਂ { $page } ਸਫ਼ਾ

## Find panel button title and messages

pdfjs-find-input =
    .placeholder = …ਦਸਤਾਵੇਜ਼ 'ਚ ਲੱਭੋ
    .title = ਲੱਭੋ
pdfjs-find-previous-button =
    .title = ਵਾਕ ਦੀ ਪਿਛਲੀ ਮੌਜੂਦਗੀ ਲੱਭੋ
pdfjs-find-previous-button-label = ਪਿੱਛੇ
pdfjs-find-next-button =
    .title = ਵਾਕ ਦੀ ਅਗਲੀ ਮੌਜੂਦਗੀ ਲੱਭੋ
pdfjs-find-next-button-label = ਅੱਗੇ
pdfjs-find-highlight-checkbox = ਸਭ ਉਭਾਰੋ
pdfjs-find-match-case-checkbox-label = ਅੱਖਰ ਆਕਾਰ ਨੂੰ ਮਿਲਾਉ
pdfjs-find-match-diacritics-checkbox-label = ਭੇਦਸੂਚਕ ਮੇਲ
pdfjs-find-entire-word-checkbox-label = ਪੂਰੇ ਸ਼ਬਦ
pdfjs-find-reached-top = ਦਸਤਾਵੇਜ਼ ਦੇ ਉੱਤੇ ਆ ਗਏ ਹਾਂ, ਥੱਲੇ ਤੋਂ ਜਾਰੀ ਰੱਖਿਆ ਹੈ
pdfjs-find-reached-bottom = ਦਸਤਾਵੇਜ਼ ਦੇ ਅੰਤ ਉੱਤੇ ਆ ਗਏ ਹਾਂ, ਉੱਤੇ ਤੋਂ ਜਾਰੀ ਰੱਖਿਆ ਹੈ
# Variables:
#   $current (Number) - the index of the currently active find result
#   $total (Number) - the total number of matches in the document
pdfjs-find-match-count =
    { $total ->
        [one] { $total } ਵਿੱਚੋਂ { $current } ਮੇਲ
       *[other] { $total } ਵਿੱਚੋਂ { $current } ਮੇਲ
    }
# Variables:
#   $limit (Number) - the maximum number of matches
pdfjs-find-match-count-limit =
    { $limit ->
        [one] { $limit } ਤੋਂ ਵੱਧ ਮੇਲ
       *[other] { $limit } ਤੋਂ ਵੱਧ ਮੇਲ
    }
pdfjs-find-not-found = ਵਾਕ ਨਹੀਂ ਲੱਭਿਆ

## Predefined zoom values

pdfjs-page-scale-width = ਸਫ਼ੇ ਦੀ ਚੌੜਾਈ
pdfjs-page-scale-fit = ਸਫ਼ਾ ਫਿੱਟ
pdfjs-page-scale-auto = ਆਟੋਮੈਟਿਕ ਜ਼ੂਮ ਕਰੋ
pdfjs-page-scale-actual = ਆਟੋਮੈਟਿਕ ਆਕਾਰ
# Variables:
#   $scale (Number) - percent value for page scale
pdfjs-page-scale-percent = { $scale }%

## PDF page

# Variables:
#   $page (Number) - the page number
pdfjs-page-landmark =
    .aria-label = ਸਫ਼ਾ { $page }

## Loading indicator messages

pdfjs-loading-error = PDF ਲੋਡ ਕਰਨ ਦੇ ਦੌਰਾਨ ਗਲਤੀ ਆਈ ਹੈ।
pdfjs-invalid-file-error = ਗਲਤ ਜਾਂ ਨਿਕਾਰਾ PDF ਫਾਈਲ ਹੈ।
pdfjs-missing-file-error = ਨਾ-ਮੌਜੂਦ PDF ਫਾਈਲ।
pdfjs-unexpected-response-error = ਅਣਜਾਣ ਸਰਵਰ ਜਵਾਬ।
pdfjs-rendering-error = ਸਫ਼ਾ ਰੈਡਰ ਕਰਨ ਦੇ ਦੌਰਾਨ ਗਲਤੀ ਆਈ ਹੈ।

## Annotations

# .alt: This is used as a tooltip.
# Variables:
#   $type (String) - an annotation type from a list defined in the PDF spec
# (32000-1:2008 Table 169 – Annotation types).
# Some common types are e.g.: "Check", "Text", "Comment", "Note"
pdfjs-text-annotation-type =
    .alt = [{ $type } ਵਿਆਖਿਆ]
# Variables:
#   $dateObj (Date) - the modification date and time of the annotation
pdfjs-annotation-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }

## Password

pdfjs-password-label = ਇਹ PDF ਫਾਈਲ ਨੂੰ ਖੋਲ੍ਹਣ ਲਈ ਪਾਸਵਰਡ ਦਿਉ।
pdfjs-password-invalid = ਗਲਤ ਪਾਸਵਰਡ। ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ ਜੀ।
pdfjs-password-ok-button = ਠੀਕ ਹੈ
pdfjs-password-cancel-button = ਰੱਦ ਕਰੋ
pdfjs-web-fonts-disabled = ਵੈਬ ਫੋਂਟ ਬੰਦ ਹਨ: ਇੰਬੈਡ PDF ਫੋਂਟ ਨੂੰ ਵਰਤਣ ਲਈ ਅਸਮਰੱਥ ਹੈ।

## Editing

pdfjs-editor-free-text-button =
    .title = ਲਿਖਤ
pdfjs-editor-color-picker-free-text-input =
    .title = ਲਿਖਤ ਦੇ ਰੰਗ ਨੂੰ ਬਦਲੋ
pdfjs-editor-free-text-button-label = ਲਿਖਤ
pdfjs-editor-ink-button =
    .title = ਵਾਹੋ
pdfjs-editor-color-picker-ink-input =
    .title = ਡਰਾਇੰਗ ਰੰਗ ਨੂੰ ਬਦਲੋ
pdfjs-editor-ink-button-label = ਵਾਹੋ
pdfjs-editor-stamp-button =
    .title = ਚਿੱਤਰ ਜੋੜੋ ਜਾਂ ਸੋਧੋ
pdfjs-editor-stamp-button-label = ਚਿੱਤਰ ਜੋੜੋ ਜਾਂ ਸੋਧੋ
pdfjs-editor-highlight-button =
    .title = ਹਾਈਲਾਈਟ
pdfjs-editor-highlight-button-label = ਹਾਈਲਾਈਟ
pdfjs-highlight-floating-button1 =
    .aria-label = ਹਾਈਲਾਈਟ
    .title = ਹਾਈਲਾਈਟ
pdfjs-highlight-floating-button-label = ਹਾਈਲਾਈਟ
pdfjs-comment-floating-button =
    .aria-label = ਟਿੱਪਣੀ
    .title = ਟਿੱਪਣੀ
pdfjs-comment-floating-button-label = ਟਿੱਪਣੀ
pdfjs-editor-comment-button =
    .aria-label = ਟਿੱਪਣੀ
    .title = ਟਿੱਪਣੀ
pdfjs-editor-comment-button-label = ਟਿੱਪਣੀ
pdfjs-editor-signature-button =
    .title = ਦਸਤਖ਼ਤ ਜੋੜੋ
pdfjs-editor-signature-button-label = ਦਸਤਖ਼ਤ ਜੋੜੋ

## Default editor aria labels

# “Highlight” is a noun, the string is used on the editor for highlights.
pdfjs-editor-highlight-editor =
    .aria-label = ਹਾਈਲਾਈਟ ਸੰਪਾਦਕ
# “Drawing” is a noun, the string is used on the editor for drawings.
pdfjs-editor-ink-editor =
    .aria-label = ਡਰਾਇੰਗ ਸੰਪਾਦਕ
# Used when a signature editor is selected/hovered.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-signature-editor1 =
    .aria-description = ਦਸਤਖ਼ਤ ਐਡੀਟਰ: { $description }
pdfjs-editor-stamp-editor =
    .aria-label = ਚਿੱਤਰ ਸੰਪਾਦਕ

## Remove button for the various kind of editor.

pdfjs-editor-remove-ink-button =
    .title = ਡਰਾਇੰਗ ਨੂੰ ਹਟਾਓ
pdfjs-editor-remove-freetext-button =
    .title = ਲਿਖਤ ਨੂੰ ਹਟਾਓ
pdfjs-editor-remove-stamp-button =
    .title = ਚਿੱਤਰ ਨੂੰ ਹਟਾਓ
pdfjs-editor-remove-highlight-button =
    .title = ਹਾਈਲਾਈਟ ਨੂੰ ਹਟਾਓ
pdfjs-editor-remove-signature-button =
    .title = ਦਸਤਖ਼ਤ ਨੂੰ ਹਟਾਓ

##

# Editor Parameters
pdfjs-editor-free-text-color-input = ਰੰਗ
pdfjs-editor-free-text-size-input = ਆਕਾਰ
pdfjs-editor-ink-color-input = ਰੰਗ
pdfjs-editor-ink-thickness-input = ਮੋਟਾਈ
pdfjs-editor-ink-opacity-input = ਧੁੰਦਲਾਪਨ
pdfjs-editor-stamp-add-image-button =
    .title = ਚਿੱਤਰ ਜੋੜੋ
pdfjs-editor-stamp-add-image-button-label = ਚਿੱਤਰ ਜੋੜੋ
# This refers to the thickness of the line used for free highlighting (not bound to text)
pdfjs-editor-free-highlight-thickness-input = ਮੋਟਾਈ
pdfjs-editor-free-highlight-thickness-title =
    .title = ਚੀਜ਼ਾਂ ਨੂੰ ਹੋਰ ਲਿਖਤਾਂ ਤੋਂ ਉਘਾੜਨ ਸਮੇਂ ਮੋਟਾਈ ਨੂੰ ਬਦਲੋ
pdfjs-editor-add-signature-container =
    .aria-label = ਦਸਤਖ਼ਤ ਕੰਟਰੋਲ ਅਤੇ ਸੰਭਾਲੇ ਹੋਏ ਦਸਤਖ਼ਤ
pdfjs-editor-signature-add-signature-button =
    .title = ਨਵੇਂ ਦਸਤਖ਼ਤ ਨੂੰ ਜੋੜੋ
pdfjs-editor-signature-add-signature-button-label = ਨਵੇਂ ਦਸਤਖ਼ਤ ਨੂੰ ਜੋੜੋ
# Used on the button to use an already saved signature.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-add-saved-signature-button =
    .title = ਸੰਭਾਲੇ ਦਸਤਖ਼ਤ: { $description }
# .default-content is used as a placeholder in an empty text editor.
pdfjs-free-text2 =
    .aria-label = ਲਿਖਤ ਐਡੀਟਰ
    .default-content = …ਲਿਖਣਾ ਸ਼ੁਰੂ ਕਰੋ
# Used to show how many comments are present in the pdf file.
# Variables:
#   $count (Number) - the number of comments.
pdfjs-editor-comments-sidebar-title =
    { $count ->
        [one] ਟਿੱਪਣੀ
       *[other] ਟਿੱਪਣੀਆਂ
    }
pdfjs-editor-comments-sidebar-close-button =
    .aria-label = ਬਾਹੀ ਨੂੰ ਬੰਦ ਕਰੋ
    .title = ਬਾਹੀ ਨੂੰ ਬੰਦ ਕਰੋ
pdfjs-editor-comments-sidebar-close-button-label = ਬਾਹੀ ਨੂੰ ਬੰਦ ਕਰੋ
# Instructional copy to add a comment by selecting text or an annotations.
pdfjs-editor-comments-sidebar-no-comments1 = ਕੀ ਕੁਝ ਧਿਆਨ ਦੇਣ ਯੋਗ ਵੇਖਿਆ ਹੈ? ਇਸ ਨੂੰ ਉਘਾੜੋ ਅਤੇ ਟਿੱਪਣੀ ਦਿਓ।
pdfjs-editor-comments-sidebar-no-comments-link = ਹੋਰ ਜਾਣੋ

## Alt-text dialog

pdfjs-editor-alt-text-button-label = ਬਦਲਵੀਂ ਲਿਖਤ
pdfjs-editor-alt-text-edit-button =
    .aria-label = ਬਦਲਵੀ ਲਿਖਤ ਨੂੰ ਸੋਧੋ
pdfjs-editor-alt-text-dialog-label = ਚੋਣ ਕਰੋ
pdfjs-editor-alt-text-dialog-description = ਚਿੱਤਰ ਨਾ ਦਿੱਸਣ ਜਾਂ ਲੋਡ ਨਾ ਹੋਣ ਦੀ ਹਾਲਤ ਵਿੱਚ Alt ਲਿਖਤ (ਬਦਲਵੀਂ ਲਿਖਤ) ਲੋਕਾਂ ਲਈ ਮਦਦਗਾਰ ਹੁੰਦੀ ਹੈ।
pdfjs-editor-alt-text-add-description-label = ਵਰਣਨ ਜੋੜੋ
pdfjs-editor-alt-text-add-description-description = 1-2 ਵਾਕ ਰੱਖੋ, ਜੋ ਕਿ ਵਿਸ਼ੇ, ਸੈਟਿੰਗ ਜਾਂ ਕਾਰਵਾਈਆਂ ਬਾਰੇ ਦਰਸਾਉਂਦੇ ਹੋਣ।
pdfjs-editor-alt-text-mark-decorative-label = ਸਜਾਵਟ ਵਜੋਂ ਨਿਸ਼ਾਨ ਲਾਇਆ
pdfjs-editor-alt-text-mark-decorative-description = ਇਸ ਨੂੰ ਸਜਾਵਟੀ ਚਿੱਤਰਾਂ ਲਈ ਵਰਤਿਆ ਜਾਂਦਾ ਹੈ ਜਿਵੇਂ ਕਿ ਹਾਸ਼ੀਆ ਜਾਂ ਵਾਟਰਮਾਰਕ ਆਦਿ।
pdfjs-editor-alt-text-cancel-button = ਰੱਦ ਕਰੋ
pdfjs-editor-alt-text-save-button = ਸੰਭਾਲੋ
pdfjs-editor-alt-text-decorative-tooltip = ਸਜਾਵਟ ਵਜੋਂ ਨਿਸ਼ਾਨ ਲਾਓ
# .placeholder: This is a placeholder for the alt text input area
pdfjs-editor-alt-text-textarea =
    .placeholder = ਮਿਸਾਲ ਵਜੋਂ, “ਗੱਭਰੂ ਭੋਜਨ ਲੈ ਕੇ ਮੇਜ਼ ਉੱਤੇ ਬੈਠਾ ਹੈ”
# Alternative text (alt text) helps when people can't see the image.
pdfjs-editor-alt-text-button =
    .aria-label = ਬਦਲਵੀਂ ਲਿਖਤ

## Editor resizers
## This is used in an aria label to help to understand the role of the resizer.

pdfjs-editor-resizer-top-left =
    .aria-label = ਉੱਤੇ ਖੱਬਾ ਕੋਨਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-top-middle =
    .aria-label = ਉੱਤੇ ਮੱਧ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-top-right =
    .aria-label = ਉੱਤੇ ਸੱਜਾ ਕੋਨਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-middle-right =
    .aria-label = ਮੱਧ ਸੱਜਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-bottom-right =
    .aria-label = ਹੇਠਾਂ ਸੱਜਾ ਕੋਨਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-bottom-middle =
    .aria-label = ਹੇਠਾਂ ਮੱਧ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-bottom-left =
    .aria-label = ਹੇਠਾਂ ਖੱਬਾ ਕੋਨਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ
pdfjs-editor-resizer-middle-left =
    .aria-label = ਮੱਧ ਖੱਬਾ — ਮੁੜ-ਆਕਾਰ ਕਰੋ

## Color picker

# This means "Color used to highlight text"
pdfjs-editor-highlight-colorpicker-label = ਹਾਈਟਲਾਈਟ ਦਾ ਰੰਗ
pdfjs-editor-colorpicker-button =
    .title = ਰੰਗ ਨੂੰ ਬਦਲੋ
pdfjs-editor-colorpicker-dropdown =
    .aria-label = ਰੰਗ ਚੋਣਾਂ
pdfjs-editor-colorpicker-yellow =
    .title = ਪੀਲਾ
pdfjs-editor-colorpicker-green =
    .title = ਹਰਾ
pdfjs-editor-colorpicker-blue =
    .title = ਨੀਲਾ
pdfjs-editor-colorpicker-pink =
    .title = ਗੁਲਾਬੀ
pdfjs-editor-colorpicker-red =
    .title = ਲਾਲ

## Show all highlights
## This is a toggle button to show/hide all the highlights.

pdfjs-editor-highlight-show-all-button-label = ਸਭ ਵੇਖੋ
pdfjs-editor-highlight-show-all-button =
    .title = ਸਭ ਵੇਖੋ

## New alt-text dialog
## Group note for entire feature: Alternative text (alt text) helps when people can't see the image. This feature includes a tool to create alt text automatically using an AI model that works locally on the user's device to preserve privacy.

# Modal header positioned above a text box where users can edit the alt text.
pdfjs-editor-new-alt-text-dialog-edit-label = ਬਦਲਵੀਂ ਲਿਖਤ (ਚਿੱਤਰ ਦਾ ਵਰਣਨ) ਨੂੰ ਸੋਧੋ
# Modal header positioned above a text box where users can add the alt text.
pdfjs-editor-new-alt-text-dialog-add-label = ਬਦਲਵੀਂ ਲਿਖਤ (ਚਿੱਤਰ ਦਾ ਵਰਣਨ) ਨੂੰ ਜੋੜੋ
pdfjs-editor-new-alt-text-textarea =
    .placeholder = …ਆਪਣਾ ਵਰਣਨਾ ਇੱਥੇ ਲਿਖੋ
# This text refers to the alt text box above this description. It offers a definition of alt text.
pdfjs-editor-new-alt-text-description = ਲੋਕ, ਜੋ ਕਿ ਚਿੱਤਰ ਨਹੀਂ ਵੇਖ ਸਕਦੇ ਜਾਂ ਜਦ ਵੀ ਚਿੱਤਰਾਂ ਨੂੰ ਲੋਡ ਨਹੀਂ ਜਾ ਸਕਦਾ, ਉਸ ਲਈ ਛੋਟਾ ਵੇਰਵਾ ਦਿਓ।
# This is a required legal disclaimer that refers to the automatically created text inside the alt text box above this text. It disappears if the text is edited by a human.
pdfjs-editor-new-alt-text-disclaimer1 = ਇਹ ਬਦਲਵੀਂ ਲਿਖਤ ਆਪਣੇ-ਆਪ ਤਿਆਰ ਕੀਤੀ ਗਈ ਸੀ ਅਤੇ ਗਲਤ ਵੀ ਹੋ ਸਕਦੀ ਹੈ।
pdfjs-editor-new-alt-text-disclaimer-learn-more-url = ਹੋਰ ਜਾਣੋ
pdfjs-editor-new-alt-text-create-automatically-button-label = ਬਲਦਵੀਂ ਲਿਖਤ ਆਪਣੇ-ਆਪ ਬਣਾਓ
pdfjs-editor-new-alt-text-not-now-button = ਹੁਣੇ ਨਹੀਂ
pdfjs-editor-new-alt-text-error-title = ਬਦਲਵੀਂ ਲਿਖਤ ਆਪਣੇ-ਆਪ ਬਣਾਈ ਨਹੀਂ ਜਾ ਸਕੀ
pdfjs-editor-new-alt-text-error-description = ਆਪਣਾ ਖੁਦ ਦੀ ਬਦਲਵੀਂ ਲਿਖਤ ਲਿਖੋ ਜਾਂ ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-editor-new-alt-text-error-close-button = ਬੰਦ ਕਰੋ
# Variables:
#   $totalSize (Number) - the total size (in MB) of the AI model.
#   $downloadedSize (Number) - the downloaded size (in MB) of the AI model.
pdfjs-editor-new-alt-text-ai-model-downloading-progress = ਬਦਲਵਾਂ ਲਿਖਤ AI ਮਾਡਲ ਡਾਊਨਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ ({ $totalSize } MB ਵਿੱਚੋਂ { $downloadedSize })
    .aria-valuetext = ਬਦਲਵਾਂ ਲਿਖਤ AI ਮਾਡਲ ਡਾਊਨਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ ({ $totalSize } MB ਵਿੱਚੋਂ { $downloadedSize })
# This is a button that users can click to edit the alt text they have already added.
pdfjs-editor-new-alt-text-added-button =
    .aria-label = ਬਦਲਵੀਂ ਲਿਖਤ ਜੋੜੀ
pdfjs-editor-new-alt-text-added-button-label = ਬਦਲਵੀਂ ਲਿਖਤ ਜੋੜੀ
# This is a button that users can click to open the alt text editor and add alt text when it is not present.
pdfjs-editor-new-alt-text-missing-button =
    .aria-label = ਬਦਲਵਾਂ ਲਿਖਤ ਗੁੰਮ ਹੈ
pdfjs-editor-new-alt-text-missing-button-label = ਬਦਲਵਾਂ ਲਿਖਤ ਗੁੰਮ ਹੈ
# This is a button that opens up the alt text modal where users should review the alt text that was automatically generated.
pdfjs-editor-new-alt-text-to-review-button =
    .aria-label = ਬਦਲਵੀਂ ਲਿਖਤ ਦਾ ਰੀਵਿਊ ਕਰੋ
pdfjs-editor-new-alt-text-to-review-button-label = ਬਦਲਵੀਂ ਲਿਖਤ ਦਾ ਰੀਵਿਊ ਕਰੋ
# "Created automatically" is a prefix that will be added to the beginning of any alt text that has been automatically generated. After the colon, the user will see/hear the actual alt text description. If the alt text has been edited by a human, this prefix will not appear.
# Variables:
#   $generatedAltText (String) - the generated alt-text.
pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer = ਆਪਣੇ-ਆਪ ਬਣਾਇਆ: { $generatedAltText }

## Image alt-text settings

pdfjs-image-alt-text-settings-button =
    .title = ਚਿੱਤਰ ਬਦਲਵੀਂ ਲਿਖਤ ਦੀਆਂ ਸੈਟਿੰਗਾਂ
pdfjs-image-alt-text-settings-button-label = ਚਿੱਤਰ ਬਦਲਵੀਂ ਲਿਖਤ ਦੀਆਂ ਸੈਟਿੰਗਾਂ
pdfjs-editor-alt-text-settings-dialog-label = ਚਿੱਤਰ ਬਦਲਵੀਂ ਲਿਖਤ ਦੀਆਂ ਸੈਟਿੰਗਾਂ
pdfjs-editor-alt-text-settings-automatic-title = ਆਟੋਮਮੈਟਿਕ ਬਦਲਵੀਂ ਲਿਖਤ
pdfjs-editor-alt-text-settings-create-model-button-label = ਬਲਦਵੀਂ ਲਿਖਤ ਆਪਣੇ-ਆਪ ਬਣਾਓ
pdfjs-editor-alt-text-settings-create-model-description = ਚਿੱਤਰ ਨਾ ਵੇਖ ਸਕਣ ਵਾਲੇ ਲੋਕਾਂ ਦੀ ਮਦਦ ਜਾਂ ਜਦ ਵੀ ਚਿੱਤਰਾਂ ਨੂੰ ਲੋਡ ਨਹੀਂ ਜਾ ਸਕਦਾ, ਉਸ ਲਈ ਛੋਟਾ ਵੇਰਵਾ ਦਿਓ।
pdfjs-editor-alt-text-settings-editor-title = ਬਦਲਵੀਂ ਲਿਖਤ ਐਡੀਟਰ
pdfjs-editor-alt-text-settings-show-dialog-button-label = ਜਦੋਂ ਵਿੱਚ ਚਿੱਤਰ ਜੋੜਿਆ ਜਾਵੇ ਤਾਂ ਫ਼ੌਰਨ ਬਦਲਵੀ ਲਿਖਤ ਸੰਪਾਦਕ ਵੇਖਾਓ
pdfjs-editor-alt-text-settings-show-dialog-description = ਤੁਹਾਡੀ ਮਦਦ ਕਰਦਾ ਹੈ ਕਿ ਤੁਹਾਡੇ ਸਾਰੇ ਚਿੱਤਰਾਂ ਲਈ ਬਦਲਵੀਂ ਲਿਖਤ ਮੌਜੂਦ ਹੋਵੇ।
pdfjs-editor-alt-text-settings-close-button = ਬੰਦ ਕਰੋ

## Accessibility labels (announced by screen readers) for objects added to the editor.

pdfjs-editor-highlight-added-alert = ਹਾਈਲਾਈਟ ਨੂੰ ਜੋੜਿਆ
pdfjs-editor-freetext-added-alert = ਲਿਖਤ ਨੂੰ ਜੋੜਿਆ ਗਿਆ
pdfjs-editor-ink-added-alert = ਡਰਾਇੰਗ ਨੂੰ ਜੋੜਿਆ
pdfjs-editor-stamp-added-alert = ਚਿੱਤਰ ਨੂੰ ਜੋੜਿਆ
pdfjs-editor-signature-added-alert = ਦਸਤਖ਼ਤਾਂ ਨੂੰ ਜੋੜਿਆ

## "Annotations removed" bar

pdfjs-editor-undo-bar-message-highlight = ਹਾਈਲਾਈਟ ਨੂੰ ਹਟਾਇਆ ਗਿਆ
pdfjs-editor-undo-bar-message-freetext = ਲਿਖਤ ਨੂੰ ਹਟਾਇਆ ਗਿਆ
pdfjs-editor-undo-bar-message-ink = ਡਰਾਇੰਗ ਨੂੰ ਹਟਾਇਆ ਗਿਆ
pdfjs-editor-undo-bar-message-stamp = ਚਿੱਤਰ ਨੂੰ ਹਟਾਇਆ ਗਿਆ
pdfjs-editor-undo-bar-message-signature = ਦਸਤਖ਼ਤ ਨੂੰ ਹਟਾਇਆ
pdfjs-editor-undo-bar-message-comment = ਟਿੱਪਣੀ ਨੂੰ ਹਟਾਇਆ ਗਿਆ
# Variables:
#   $count (Number) - the number of removed annotations.
pdfjs-editor-undo-bar-message-multiple =
    { $count ->
        [one] { $count } ਵਿਆਖਿਆ ਨੂੰ ਹਟਾਇਆ
       *[other] { $count } ਵਿਆਖਿਆਵਾਂ ਨੂੰ ਹਟਾਇਆ
    }
pdfjs-editor-undo-bar-undo-button =
    .title = ਵਾਪਸ
pdfjs-editor-undo-bar-undo-button-label = ਵਾਪਸ
pdfjs-editor-undo-bar-close-button =
    .title = ਬੰਦ ਕਰੋ
pdfjs-editor-undo-bar-close-button-label = ਬੰਦ ਕਰੋ

## Add a signature dialog

pdfjs-editor-add-signature-dialog-label = ਇਹ ਮਾਡਲ ਵਰਤੋਂਕਾਰ ਨੂੰ PDF ਦਸਤਾਵੇਜ਼ ਵਿੱਚ ਜੋੜਨ ਲਈ ਦਸਤਖ਼ਤ ਬਣਾਉਣ ਦਿੰਦਾ ਹੈ। ਵਰਤੋਂਕਾਰ ਨਾਂ ਨੂੰ ਸੋਧ ਸਕਦਾ ਹੈ (ਜੋ ਕਿ ਬਦਲਵੀਂ ਲਿਖਤ ਵਜੋਂ ਕੰਮ ਕਰੇਗਾ) ਅਤੇ ਦੁਬਾਰਾ ਵਰਤੋਂ ਕਰਨ ਲਈ ਦਸਤਖ਼ਤਾਂ ਨੂੰ ਸੰਭਾਲ ਵੀ ਸਕਦਾ ਹੈ।
pdfjs-editor-add-signature-dialog-title = ਦਸਤਖ਼ਤ ਨੂੰ ਜੋੜੋ

## Tab names

# Type is a verb (you can type your name as signature)
pdfjs-editor-add-signature-type-button = ਕਿਸਮ
    .title = ਕਿਸਮ
# Draw is a verb (you can draw your signature)
pdfjs-editor-add-signature-draw-button = ਵਾਹੋ
    .title = ਵਾਹੋ
pdfjs-editor-add-signature-image-button = ਚਿੱਤਰ
    .title = ਚਿੱਤਰ

## Tab panels

pdfjs-editor-add-signature-type-input =
    .aria-label = ਆਪਣੇ ਦਸਤਖ਼ਤ ਨੂੰ ਟਾਈਪ ਕਰੋ
    .placeholder = ਆਪਣੇ ਦਸਤਖ਼ਤ ਨੂੰ ਟਾਈਪ ਕਰੋ
pdfjs-editor-add-signature-draw-placeholder = ਆਪਣੇ ਦਸਤਖ਼ਤ ਨੂੰ ਵਾਹੋ
pdfjs-editor-add-signature-draw-thickness-range-label = ਮੋਟਾਈ
# Variables:
#   $thickness (Number) - the thickness (in pixels) of the line used to draw a signature.
pdfjs-editor-add-signature-draw-thickness-range =
    .title = ਵਹਾਉਣ ਲਈ ਚੌੜਾਈ: { $thickness }
pdfjs-editor-add-signature-image-placeholder = ਅੱਪਲੋਡ ਕਰਨ ਲਈ ਫ਼ਾਇਲ ਨੂੰ ਇੱਥੇ ਖਿੱਚੋ
pdfjs-editor-add-signature-image-browse-link =
    { PLATFORM() ->
        [macos] ਜਾਂ ਚਿੱਤਰ ਫ਼ਾਇਲਾਂ ਨੂੰ ਚੁਣੋ
       *[other] ਜਾਂ ਚਿੱਤਰ ਫ਼ਾਇਲਾਂ ਦੀ ਝਲਕ ਵੇਖੋ
    }

## Controls

pdfjs-editor-add-signature-description-label = ਵਰਣਨ (ਬਦਲਵੀਂ ਲਿਖਤ)
pdfjs-editor-add-signature-description-input =
    .title = ਵਰਣਨ (ਬਦਲਵੀਂ ਲਿਖਤ)
pdfjs-editor-add-signature-description-default-when-drawing = ਦਸਤਖ਼ਤ
pdfjs-editor-add-signature-clear-button-label = ਦਸਤਖ਼ਤ ਨੂੰ ਮਿਟਾਓ
pdfjs-editor-add-signature-clear-button =
    .title = ਦਸਤਖ਼ਤ ਨੂੰ ਮਿਟਾਓ
pdfjs-editor-add-signature-save-checkbox = ਦਸਤਖ਼ਤ ਨੂੰ ਸੰਭਾਲੋ
pdfjs-editor-add-signature-save-warning-message = ਤੁਸੀਂ ਵੱਧ ਤੋਂ ਵੱਧ 5 ਸੰਭਾਲੇ ਦਸਤਖ਼ਤਾਂ ਦੀ ਹੱਦ ਤੱਕ ਅੱਪੜੇ। ਹੋਰ ਸੰਭਾਲਣ ਲਈ ਇੱਕ ਨੂੰ ਹਟਾਓ।
pdfjs-editor-add-signature-image-upload-error-title = ਚਿੱਤਰ ਨੂੰ ਅੱਪਲੋਡ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਿਆ
pdfjs-editor-add-signature-image-upload-error-description = ਆਪਣੇ ਕਨੈਕਸ਼ਨ ਦੀ ਜਾਂਚ ਕਰੋ ਜਾਂ ਹੋਰ ਚਿੱਤਰ ਨੂੰ ਅਜ਼ਮਾਓ।
pdfjs-editor-add-signature-image-no-data-error-title = ਇਸ ਚਿੱਤਰ ਨੂੰ ਦਸਤਖ਼ਤ ਵਿੱਚ ਬਦਲਿਆ ਨਹੀਂ ਜਾ ਸਕਦਾ ਹੈ
pdfjs-editor-add-signature-image-no-data-error-description = ਵੱਖਰੇ ਚਿੱਤਰ ਨੂੰ ਅੱਪਲੋਡ ਕਰਨ ਦੀ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-editor-add-signature-error-close-button = ਬੰਦ ਕਰੋ

## Dialog buttons

pdfjs-editor-add-signature-cancel-button = ਰੱਦ ਕਰੋ
pdfjs-editor-add-signature-add-button = ਜੋੜੋ
pdfjs-editor-edit-signature-update-button = ਅੱਪਡੇਟ

## Comment popup

pdfjs-editor-edit-comment-popup-button-label = ਟਿੱਪਣੀ ਨੂੰ ਸੋਧੋ
pdfjs-editor-edit-comment-popup-button =
    .title = ਟਿੱਪਣੀ ਨੂੰ ਸੋਧੋ
pdfjs-editor-delete-comment-popup-button-label = ਟਿੱਪਣੀ ਨੂੰ ਹਟਾਓ
pdfjs-editor-delete-comment-popup-button =
    .title = ਟਿੱਪਣੀ ਨੂੰ ਹਟਾਓ
pdfjs-show-comment-button =
    .title = ਟਿੱਪਣੀ ਨੂੰ ਵੇਖਾਓ

##  Edit a comment dialog

# An existing comment is edited
pdfjs-editor-edit-comment-dialog-title-when-editing = ਟਿੱਪਣੀ ਨੂੰ ਸੋਧੋ
pdfjs-editor-edit-comment-dialog-save-button-when-editing = ਅੱਪਡੇਟ ਕਰੋ
# No existing comment
pdfjs-editor-edit-comment-dialog-title-when-adding = ਟਿੱਪਣੀ ਜੋੜੋ
pdfjs-editor-edit-comment-dialog-save-button-when-adding = ਜੋੜੋ
pdfjs-editor-edit-comment-dialog-text-input =
    .placeholder = …ਲਿਖਣਾ ਸ਼ੁਰੂ ਕਰੋ
pdfjs-editor-edit-comment-dialog-cancel-button = ਰੱਦ ਕਰੋ

## Edit a comment button in the editor toolbar

pdfjs-editor-add-comment-button =
    .title = ਟਿੱਪਣੀ ਜੋੜੋ

## The view manager is a sidebar displaying different views:
##  - thumbnails;
##  - outline;
##  - attachments;
##  - layers.
## The thumbnails view is used to edit the pdf: remove/insert pages, ...

pdfjs-toggle-views-manager-notification-button =
    .title = ਬਾਹੀ ਨੂੰ ਬਦਲੋ (ਦਸਤਾਵੇਜ਼ ਥੰਮਨੇਲ/ਆਨਲਾਈਨਅਟੈਚਮੈਂਟ/ਪਰਤਾਂ ਰੱਖਦਾ ਹੈ)
pdfjs-toggle-views-manager-button1-label = ਸਫ਼ਿਆਂ ਦਾ ਇੰਤਜ਼ਾਮ
pdfjs-views-manager-sidebar =
    .aria-label = ਬਾਹੀ
pdfjs-views-manager-sidebar-resizer =
    .aria-label = ਬਾਹੀ ਦਾ ਆਕਾਰ-ਬਦਲ
pdfjs-views-manager-view-selector-button =
    .title = ਵੇਖੋ
pdfjs-views-manager-view-selector-button-label = ਵੇਖੋ
pdfjs-views-manager-pages-title = ਸਫ਼ੇ
pdfjs-views-manager-outlines-title1 = ਦਸਤਾਵੇਜ਼ ਖਾਕਾ
    .title = ਦਸਤਾਵੇਜ਼ ਖਾਕਾ (ਸਾਰੀਆਂ ਚੀਜ਼ਾਂ ਨੂੰ ਫੈਲਾਉਣ/ਸਮੇਟਣ ਲਈ ਦੋ ਵਾਰ ਕਲਿੱਕ ਕਰੋ)
pdfjs-views-manager-attachments-title = ਅਟੈਚਮੈਂਟਾਂ
pdfjs-views-manager-layers-title1 = ਲੇਅਰ
    .title = ਲੇਅਰ (ਸਾਰੀਆਂ ਲੇਅਰਾਂ ਨੂੰ ਮੂਲ ਹਾਲਤ ਵਿੱਚ ਲੈ ਜਾਣ ਲਈ ਦੋ ਵਾਰ ਕਲਿੱਕ ਕਰੋ)
pdfjs-views-manager-pages-option-label = ਸਫ਼ੇ
pdfjs-views-manager-outlines-option-label = ਦਸਤਾਵੇਜ਼ ਆਉਟਲਾਈਨ
pdfjs-views-manager-attachments-option-label = ਅਟੈਚਮੈਂਟਾਂ
pdfjs-views-manager-layers-option-label = ਪਰਤਾਂ
pdfjs-views-manager-add-file-button =
    .title = ਫ਼ਾਇਲ ਨੂੰ ਜੋੜੋ
pdfjs-views-manager-add-file-button-label = ਫ਼ਾਇਲ ਨੂੰ ਜੋੜੋ
# Variables:
#   $count (Number) - the number of selected pages.
pdfjs-views-manager-pages-status-action-label =
    { $count ->
        [one] { $count } ਚੁਣਿਆ
       *[other] { $count } ਚੁਣੇ
    }
pdfjs-views-manager-pages-status-none-action-label = ਸਫ਼ੇ ਚੁਣੋ
pdfjs-views-manager-pages-status-action-button-label = ਬੰਦੋਬਸਤ
pdfjs-views-manager-pages-status-copy-button-label = ਕਾਪੀ ਕਰੋ
pdfjs-views-manager-pages-status-cut-button-label = ਕੱਟੋ
pdfjs-views-manager-pages-status-delete-button-label = ਹਟਾਓ
pdfjs-views-manager-pages-status-export-selected-button-label = …ਚੁਣੇ ਨੂੰ ਐਕਸਪੋਰਟ ਕਰੋ
# Variables:
#   $count (Number) - the number of selected pages to be cut.
pdfjs-views-manager-status-undo-cut-label =
    { $count ->
        [one] 1 ਸਫ਼ੇ ਨੂੰ ਕੱਟਿਆਂ
       *[other] { $count } ਸਫ਼ਿਆਂ ਨੂੰ ਕੱਟਿਆਂ
    }
# Variables:
#   $count (Number) - the number of selected pages to be copied.
pdfjs-views-manager-pages-status-undo-copy-label =
    { $count ->
        [one] 1 ਸਫ਼ੇ ਨੂੰ ਕਾਪੀ ਕੀਤਾ
       *[other] { $count } ਸਫ਼ਿਆਂ ਨੂੰ ਕਾਪੀ ਕੀਤਾ
    }
# Variables:
#   $count (Number) - the number of selected pages to be deleted.
pdfjs-views-manager-pages-status-undo-delete-label =
    { $count ->
        [one] 1 ਸਫ਼ੇ ਨੂੰ ਹਟਾਇਆ
       *[other] { $count } ਸਫ਼ਿਆਂ ਨੂੰ ਹਟਾਇਆ
    }
pdfjs-views-manager-pages-status-waiting-ready-label = …ਤੁਹਾਡੀ ਫ਼ਾਇਲ ਨੂੰ ਤਿਆਰ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ
pdfjs-views-manager-pages-status-waiting-uploading-label = …ਫ਼ਾਇਲ ਨੂੰ ਅੱਪਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ
pdfjs-views-manager-status-warning-cut-label = ਕੱਟਿਆ ਨਹੀਂ ਜਾ ਸਕਿਆ। ਸਫ਼ੇ ਨੂੰ ਤਾਜ਼ਾ ਕਰਕੇ ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-views-manager-status-warning-copy-label = ਕਾਪੀ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਿਆ। ਸਫ਼ੇ ਨੂੰ ਤਾਜ਼ਾ ਕਰਕੇ ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-views-manager-status-warning-delete-label = ਹਟਾਇਆ ਨਹੀਂ ਜਾ ਸਕਿਆ। ਸਫ਼ੇ ਨੂੰ ਤਾਜ਼ਾ ਕਰਕੇ ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-views-manager-status-warning-save-label = ਸੰਭਾਲਿਆ ਨਹੀਂ ਜਾ ਸਕਿਆ। ਸਫ਼ੇ ਨੂੰ ਤਾਜ਼ਾ ਕਰਕੇ ਫੇਰ ਕੋਸ਼ਿਸ਼ ਕਰੋ।
pdfjs-views-manager-status-undo-button-label = ਵਾਪਸ
pdfjs-views-manager-status-done-button-label = ਮੁਕੰਮਲ
pdfjs-views-manager-status-close-button =
    .title = ਬੰਦ ਕਰੋ
pdfjs-views-manager-status-close-button-label = ਬੰਦ ਕਰੋ
pdfjs-views-manager-paste-button-label = ਚੇਪੋ
pdfjs-views-manager-paste-button-before =
    .title = ਪਹਿਲੇ ਸਫ਼ੇ ਦੇ ਬਾਅਦ ਚੇਪੋ
# Variables:
#   $page (Number) - the page number after which the paste button is.
pdfjs-views-manager-paste-button-after =
    .title = { $page } ਸਫ਼ੇ ਦੇ ਬਾਅਦ ਚੇਪੋ
# Badge used to promote a new feature in the UI, keep it as short as possible.
# It's spelled uppercase for English, but it can be translated as usual.
pdfjs-new-badge-content = ਨਵਾਂ
pdfjs-views-manager-waiting-for-file = …ਫ਼ਾਇਲ ਨੂੰ ਅੱਪਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ
pdfjs-toggle-views-manager-button1 =
    .title = ਸਫ਼ਿਆਂ ਦਾ ਇੰਤਜ਼ਾਮ

## Digital signature properties (signature verification panel)

pdfjs-digital-signature-properties-button =
    .aria-label = ਡਿਜੀਟਲ ਦਸਤਖਤ ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ
    .title = ਡਿਜੀਟਲ ਦਸਤਖਤ ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ
pdfjs-digital-signature-properties-button-label = ਡਿਜੀਟਲ ਦਸਤਖਤ ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ

## Banner shown above the signature list summarising the overall
## verification state of the document. Each variant is selected by the
## viewer based on the worst per-signature status; one signature is
## enough to lower the banner.
##
## Variables:
##   $count (Number) - number of signatures at the worst level.

pdfjs-digital-signature-properties-banner-verified = ਦਸਤਾਵੇਜ਼ ਨੂੰ ਵਾਜਬ ਡਿਜੀਟਲ ਦਸਤਖ਼ਤਾਂ ਨਾਲ ਸਾਈਨ ਕੀਤਾ ਗਿਆ ਸੀ
pdfjs-digital-signature-properties-banner-unknown =
    { $count ->
        [one] ਦਸਤਾਵੇਜ਼ ਨੂੰ ਸਾਈਨ ਤਾਂ ਕੀਤਾ ਗਿਆ ਸੀ ਪਰ { $count } ਡਿਜੀਟਲ ਦਸਤਖ਼ਤ ਨੂੰ ਤਸਦੀਕ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਿਆ
       *[other] ਦਸਤਾਵੇਜ਼ ਨੂੰ ਸਾਈਨ ਤਾਂ ਕੀਤਾ ਗਿਆ ਸੀ ਪਰ { $count } ਡਿਜੀਟਲ ਦਸਤਖ਼ਤਾਂ ਨੂੰ ਤਸਦੀਕ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਿਆ
    }
pdfjs-digital-signature-properties-banner-untrusted =
    { $count ->
        [one] ਦਸਤਾਵੇਜ਼ ਨੂੰ { $count } ਸਰਟੀਫਿਕੇਟ ਨਾਲ ਸਾਈਨ ਕੀਤਾ ਗਿਆ ਸੀ, ਜੋ ਭਰੋਸੇਯੋਗ ਨਹੀਂ ਹੈ
       *[other] ਦਸਤਾਵੇਜ਼ ਨੂੰ { $count } ਸਰਟੀਫਿਕੇਟਾਂ ਨਾਲ ਸਾਈਨ ਕੀਤਾ ਗਿਆ ਸੀ, ਜੋ ਭਰੋਸੇਯੋਗ ਨਹੀਂ ਹਨ
    }
pdfjs-digital-signature-properties-banner-expired =
    { $count ->
        [one] ਦਸਤਾਵੇਜ਼ ਨੂੰ { $count } ਮਿਆਦ ਪੁੱਗੇ ਸਰਟੀਫਿਕੇਟ ਨਾਲ ਸਾਈਨ ਕੀਤਾ ਗਿਆ ਸੀ
       *[other] ਦਸਤਾਵੇਜ਼ ਨੂੰ { $count } ਮਿਆਦ ਪੁੱਗੇ ਸਰਟੀਫਿਕੇਟਾਂ ਨਾਲ ਸਾਈਨ ਕੀਤਾ ਗਿਆ ਸੀ
    }
pdfjs-digital-signature-properties-banner-invalid =
    { $count ->
        [one] ਦਸਤਾਵੇਜ਼ ਵਿੱਚ { $count } ਅਵੈਧ ਡਿਜੀਟਲ ਦਸਤਖਤ ਹਨ
       *[other] ਦਸਤਾਵੇਜ਼ ਵਿੱਚ { $count } ਅਵੈਧ ਡਿਜੀਟਲ ਦਸਤਖਤ ਹਨ
    }
pdfjs-digital-signature-properties-banner-revoked =
    { $count ->
        [one] ਦਸਤਾਵੇਜ਼ 'ਤੇ { $count } ਰੱਦ ਕੀਤੇ ਸਰਟੀਫਿਕੇਟ ਨਾਲ ਦਸਤਖਤ ਕੀਤੇ ਗਏ ਹਨ
       *[other] ਦਸਤਾਵੇਜ਼ { $count } ਰੱਦ ਕੀਤੇ ਸਰਟੀਫਿਕੇਟਾਂ ਨਾਲ ਦਸਤਖਤ ਕੀਤਾ ਗਿਆ ਹੈ
    }

## Per-signature status row. Only three distinct strings are needed:
## the signature crypto either verified (the cert chain may still be
## untrusted/expired/revoked, but that's surfaced on the cert row
## below), or it failed, or its sub-format isn't supported.

pdfjs-digital-signature-properties-status-verified = ਸਥਿਤੀ: ਦਸਤਖਤਾਂ ਦੀ ਜਾਂਚ ਕੀਤੀ ਗਈ
pdfjs-digital-signature-properties-status-invalid = ਸਥਿਤੀ: ਦਸਤਖਤ ਸਹੀ ਨਹੀਂ ਹਨ
pdfjs-digital-signature-properties-status-unknown = ਸਥਿਤੀ: ਜਾਂਚ ਕਰਨ ਲਈ ਅਸਮਰੱਥ (ਗ਼ੈਰ-ਸਹਾਇਕ)

## Per-signature certificate row. The variants with an issuer / date in
## parentheses embed fully-localized context — no English fall-through.
##
## Variables:
##   $issuer (String) - issuer or subject common name from the cert.
##   $dateObj (Date)  - notAfter date for the expired-with-date form.

pdfjs-digital-signature-properties-certificate-trusted = ਸਰਟੀਫਿਕੇਟ: ਭਰੋਸਾਕਰਤਾ ({ $issuer })
pdfjs-digital-signature-properties-certificate-unknown = ਸਰਟੀਫਿਕੇਟ: ਗ਼ੈਰ-ਮੌਜੂਦ
pdfjs-digital-signature-properties-certificate-untrusted = ਸਰਟੀਫਿਕੇਟ: ਬੇਭਰੋਸੇਯੋਗ
pdfjs-digital-signature-properties-certificate-untrusted-unknown-issuer = ਸਰਟੀਫਿਕੇਟ: ਅਣਪਛਾਤਾ ਜਾਰੀਕਰਤਾ ({ $issuer })
pdfjs-digital-signature-properties-certificate-untrusted-self-signed = ਸਰਟੀਫਿਕੇਟ: ਸਵੈ-ਦਸਤਖ਼ਤੀ ({ $issuer })
pdfjs-digital-signature-properties-certificate-untrusted-untrusted-issuer = ਸਰਟੀਫਿਕੇਟ: ਬੇਭਰੋਸੇਯੋਗ ਜਾਰੀ ਕਰਤਾ ({ $issuer })
pdfjs-digital-signature-properties-certificate-expired = ਸਰਟੀਫਿਕੇਟ: ਮਿਆਦ ਪੁੱਗੀ
pdfjs-digital-signature-properties-certificate-expired-with-date = ਸਰਟੀਫਿਕੇਟ: ਮਿਆਦ ਪੁੱਗੀ ({ DATETIME($dateObj, dateStyle: "medium") })
pdfjs-digital-signature-properties-certificate-revoked = ਸਰਟੀਫਿਕੇਟ: ਰੱਦ ਕੀਤਾ

## Main menu for adding/removing signatures

pdfjs-editor-delete-signature-button1 =
    .title = ਸੰਭਾਲੇ ਹੋਏ ਦਸਤਖ਼ਤ ਨੂੰ ਹਟਾਓ
pdfjs-editor-delete-signature-button-label1 = ਸੰਭਾਲੇ ਹੋਏ ਦਸਤਖ਼ਤ ਨੂੰ ਹਟਾਓ

## Editor toolbar

pdfjs-editor-add-signature-edit-button-label = ਵਰਣਨ ਨੂੰ ਸੋਧੋ

## Edit signature description dialog

pdfjs-editor-edit-signature-dialog-title = ਵਰਣਨ ਨੂੰ ਸੋਧੋ
